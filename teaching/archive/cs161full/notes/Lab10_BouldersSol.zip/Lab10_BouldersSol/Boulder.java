import java.awt.*;
import java.awt.geom.*;
import java.util.Random;

/**
 * The Boulder class represents an Asteroids-like boulder that has a trajectory as
 * well as a current position.  It wraps around when it gets to the edge of the screen,
 * and is based on the book's Circle class, but with some extra fields and methods.
 * 
 * @author Brad Richards
 * @version 1.1
 */

public class Boulder
{
    // These fields were all there in the Circle class
    
    private int diameter;
    private double xPosition;  // This used to be an integer, but is now a double
    private double yPosition;  // This used to be an integer, but is now a double
    private String color;
    private boolean isVisible;
    
    // These new fields keep track of how quickly the boulder is moving
    
    private double xVelocity;   // How far it moves horizontally between steps
    private double yVelocity;   // How far it moves vertically between steps
    
    /**
     * Create a new boulder at specified position with specified velocity and size.
     * 
     * @param x     Starting x position
     * @param y     Starting y position
     * @param dx    How many pixels it moves horizontally per update step
     * @param dy    How many pixels it moves vertically per update step
     * @param size  The diameter of the boulder, in pixels
     */
    public Boulder(int size, double x, double y, double dx, double dy)
    {
        diameter = size;
        xPosition = x;
        yPosition = y;
        xVelocity = dx;
        yVelocity = dy;
        color = "black";
        isVisible = false;
    }
    
    /**
     * @return the String representation of a Boulder
     */
    @Override
    public String toString()
    {
        return "Boulder of size " + diameter + " is at " + xPosition + ", " + yPosition + " with velocity " + xVelocity + ", " + yVelocity;
    }

    /**
     * Uses the x and y velocities to calculate a new position for this boulder, making 
     * sure that the boulder wraps around the edges of the screen as necessary.
     */
    public void updatePosition()
    {
        // Adjust the x and y positions based on velocities
        xPosition += xVelocity;
        yPosition += yVelocity;

        // If we've gone off left or right, wrap around
        if (xPosition < 0) {
            xPosition += Canvas.getWidth();
        }
        else if (xPosition > Canvas.getWidth()) {
            xPosition -= Canvas.getWidth();
        }

        // If we've gone off the top or bottom, wrap around
        if (yPosition < 0) {
            yPosition += Canvas.getHeight();
        }
        else if (yPosition > Canvas.getHeight()) {
            yPosition -= Canvas.getHeight();
        }

        try {
            Thread.sleep(10);
        } catch(Exception e){}
        
        // Draw it in its new position
        makeVisible();
    }

    /**
     * This method checks whether we overlap with another Boulder.  It calculates the
     * distance between our center and theirs, and compares that to the sum of our
     * radius and their radius.  
     * 
     * @param other  The boulder we're comparing ourselves to
     * @return  True if we overlap with other and don't have the same parent
     */
    public boolean overlaps(Boulder other) {
        double distance;
        double ourX = xPosition + diameter/2;   // Coordinates of our center
        double ourY = yPosition + diameter/2;
        double theirX = other.xPosition + other.diameter/2;
        double theirY = other.yPosition + other.diameter/2;

        // Distance is sqrt of the x distance squared + y distance squared
        distance = Math.sqrt(       
                Math.pow(ourX-theirX,2) + 
                Math.pow(ourY-theirY,2));

        // We overlap if distance is less than our radius + their radius
        return distance < (this.diameter/2 + other.diameter/2);
    }
    
    /**
     * This accessor returns the Boulder's diameter.
     * @return  The boulder's diameter
     */
    public int getSize() {
        return diameter;
    }

    /**
     * Reverses velocity
     */
    public void reverse() {
        xVelocity = -xVelocity;
        yVelocity = -yVelocity;
    }
    
    // ------------ Methods borrowed from Circle from here on down --------------

    /**
     * Make this boulder visible. If it was already visible, do nothing.
     */
    public void makeVisible()
    {
        isVisible = true;
        draw();
    }

    /**
     * Make this boulder invisible. If it was already invisible, do nothing.
     */
    public void makeInvisible()
    {
        erase();
        isVisible = false;
    }


    /**
     * Change the size to the new size (in pixels). Size must be >= 0.
     */
    public void changeSize(int newDiameter)
    {
        erase();
        diameter = newDiameter;
        draw();
    }

    /**
     * Change the color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void changeColor(String newColor)
    {
        color = newColor;
        draw();
    }

    /**
     * Draw the boulder with current specifications on screen.
     */
    private void draw()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color, new Ellipse2D.Double(xPosition, yPosition, 
                    diameter, diameter));
        }
    }

    /**
     * Erase the boulder on screen.
     */
    private void erase()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }

}