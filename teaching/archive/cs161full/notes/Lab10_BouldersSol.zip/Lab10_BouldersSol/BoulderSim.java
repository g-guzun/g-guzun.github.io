import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;


public class BoulderSim
{
    public static void main(String[] args) throws FileNotFoundException {
        BoulderSim sim = new BoulderSim("boulders_data.txt");
        sim.animate(200);
    }
   
    
    private ArrayList<Boulder> boulderCollection;

    /**
     * Creates a collection of boulderCollection with the given file. The boulder data
     * is formatted as follows,
     * 
     *   diameter,xPosition,yPosition,xVelocity,yVelocity
     * 
     * @param filename the name of the file containing boulder information
     */
    public BoulderSim(String filename) throws FileNotFoundException
    {
        boulderCollection = new ArrayList<Boulder>();

        //open the file for reading
        Scanner filein = new Scanner(new File(filename));
        while (filein.hasNext())
        {
            String line = filein.nextLine();    //get a line of input
            String[] tokens = line.split(",");  //tokenize using "," as separator 

            //create a new boulder with the given row data, and add it to our collector
            Boulder b = new Boulder(Integer.parseInt(tokens[0]), Double.parseDouble(tokens[1]), Double.parseDouble(tokens[2]), Double.parseDouble(tokens[3]), Double.parseDouble(tokens[4]));
            b.makeVisible();
            boulderCollection.add(b);
        }
        filein.close();
    }

    /**
     * Prints all boulderCollection' information to a file
     * @param filename the output file name
     */
    public void writeToFile(String filename) throws FileNotFoundException
    {
        PrintWriter fileout = new PrintWriter(new File(filename));
        for (int i = 0; i < boulderCollection.size(); i++) {
            fileout.println((i+1) + ": " + boulderCollection.get(i).toString());
        }
        fileout.close();
    }

    /**
     * Updates every boulder's positions
     */
    public void animate(int numSteps)
    {
        for (int steps = 0; steps < numSteps; steps++) {
            //bounce off?
            for (int i = 0; i < boulderCollection.size(); i++) {
                for (int j = i+1; j < boulderCollection.size(); j++) {
                    if (boulderCollection.get(i).overlaps(boulderCollection.get(j))) {
                        boulderCollection.get(i).reverse();
                        boulderCollection.get(j).reverse();
                    }
                }
            }
            
            
            for (int i = 0; i < boulderCollection.size(); i++) {
                boulderCollection.get(i).updatePosition();
            }
        }
    }
}
