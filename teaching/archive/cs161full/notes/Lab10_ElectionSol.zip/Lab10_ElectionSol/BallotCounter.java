import java.util.*;
import java.io.*;

/**
 * Election class for Lab.
 *
 * @author David
 * @version 4/15/2020
 */
public class BallotCounter {
    private String candidateFile;               // candidate file name
    private ArrayList<String> ballotFiles;      // list of ballot filenames
    private ArrayList<String> unregisteredCandidates; 
    private HashMap<String, Integer> voteMap;   // map containing true results
    private int numBallots;
   
    /**
     * Starts a new election. This method prompts users for the names
     * of files related to the election.
     */
    public BallotCounter() {
        // instantiate empty structures
        this.ballotFiles = new ArrayList<>();
        this.unregisteredCandidates = new ArrayList<>();
        this.voteMap = new HashMap<>();
        this.numBallots = 0;
        
        // get file names from user
        Scanner keyboard = new Scanner(System.in);
        
        // get candidate file name
        System.out.print("Enter the name of candidate list: ");
        this.candidateFile = keyboard.nextLine();
        
        // get ballot file names until they input "done"
        boolean done = false;
        while (!done) {
            System.out.print("Enter the name of a ballot file (or type 'done'): ");
            String input = keyboard.nextLine();
            if (input.equalsIgnoreCase("done")) {
                done = true;
            }
            else {
                this.ballotFiles.add(input);
            }
        }
    }
    
    /**
     * Reads files and computes the results in the map.
     */
    public void runElection() throws FileNotFoundException {
        // initialize the map with candidates
        this.initializeMap();
        
        // count the ballots and update map!
        this.countBallots();
    }
    
    /**
     * Helper method for runElection to initialize the map with the names
     * of candidates from the file.
     */
    private void initializeMap() throws FileNotFoundException {
        // clear it just in case there's anything in the map
        this.voteMap.clear();

        // open the candidate file
        Scanner file = new Scanner(new File(this.candidateFile));
        while (file.hasNext()) {
            // each line in the file is a candidate's name
            // add them to the map with an initial vote count of zero
            this.voteMap.put(file.nextLine(), 0);
        }
        file.close();
    }

    /**
     * Helper method for runElection to open all ballot files, 
     * and count votes!
     */
    private void countBallots() throws FileNotFoundException {
        // Loop through all ballot files, open one by one
        for (String filename : this.ballotFiles) {
            Scanner file = new Scanner(new File(filename));
            while (file.hasNext()) {
                String candidateName = file.nextLine();
                
                // update the candidate's vote count if they are real
                if (this.voteMap.containsKey(candidateName)) {
                    int votes = this.voteMap.get(candidateName);
                    this.voteMap.put(candidateName, votes + 1);
                    this.numBallots++;
                }
                else {
                    // unregistered candidate! Add to list if they're not already in it
                    if (this.unregisteredCandidates.indexOf(candidateName) == -1) {
                        this.unregisteredCandidates.add(candidateName);
                    }
                }
            }
            file.close();
        }
    }
    
    /**
     * Determines the winners
     * @return a list of winners from the election 
     * @pre Precondition: runElection() must be run before this method
     */
    private ArrayList<String> winners() {
        ArrayList<String> winners = new ArrayList<>();
        
        // first, determine the most votes. Loop through candidates' vote counts
        int max = -1;
        for (String candidate : this.voteMap.keySet()) {
            int votes = this.voteMap.get(candidate);
            if (votes > max) {
                max = votes;
            }
        }

        // now find all the candidates who have the max vote count, add them
        // to the winners list!
        for (String candidate : this.voteMap.keySet()) {
            int votes = this.voteMap.get(candidate);
            if (votes == max) {
                winners.add(candidate);
            }
        }
        
        return winners;
    }

    /**
     * Saves the results to file.
     * @param filename file to write into
     * @pre Precondition: runElection() must be run before this method
     */
    public void saveResults(String filename) throws FileNotFoundException {
        PrintWriter out = new PrintWriter(new File(filename));
        out.println("******************************");
        out.println("       ELECTION RESULTS");
        out.println("       Ballots Cast: " + this.numBallots);
        out.println("******************************");
        
        for (String candidate : this.voteMap.keySet()) {
            int votes = this.voteMap.get(candidate);
            out.println(candidate + ": " + votes + " (" + (int) ((double) votes / this.numBallots * 100) + "%)");
        }
        out.println();
        out.println("The winner is: " + this.winners().toString());
 
        out.println();
        out.println("****************************************");
        out.println("Unregistered candidates receiving votes:");
        out.println("****************************************");
        out.println(this.unregisteredCandidates.toString());
        out.close();
    }
}