import java.awt.Color;
import java.util.Random;

/**
 * This class represents a ball that bounces around a BallCourt.
 * 
 * @author Joel Ross & David
 */
public class Ball
{
    //a constant array of colors
    private final String[] PRETTY_COLORS = {
        "red", "blue", "cyan", "green", "magenta", "orange", "pink", "white", "yellow", "black"
    };

    private int diameter; //the diameter of the ball
    private double xPosition; //the ball's xPosition
    private double yPosition; //the ball's yPosition
    private double xSpeed; //the speed the ball is moving along the x-axis
    private double ySpeed; //the speed the ball is moving along the y-axis
    private String color; //the color of the ball
    private int colorIndex; //the index of the current color of the ball
    
    //More constants are defined at the bottom of the class!
    
    /**
     * Constructor for objects of class BouncingBall
     */
    public Ball()
    {
        Random randGen = new Random();
        
        this.diameter = 40;
        this.xPosition = LEFT_BOUNDARY + randGen.nextInt(BallCourt.COURT_WIDTH - diameter);
        this.yPosition = TOP_BOUNDARY + randGen.nextInt(BallCourt.COURT_HEIGHT - diameter);
        this.xSpeed = 3.5; //or try randGen.nextDouble()*7;
        this.ySpeed = 3.5; //or try randGen.nextDouble()*7;

        //get a random color
        this.colorIndex = randGen.nextInt(this.PRETTY_COLORS.length);
        this.color = PRETTY_COLORS[this.colorIndex];
    }

    
    /**
     * Moves the ball its speed; the ball bounces off of the bounds of the BallCourt, 
     * and changes color when it does so!
     */
    public void move()
    {
        //move our speed
        this.xPosition = this.xPosition + this.xSpeed;
        this.yPosition = this.yPosition + this.ySpeed;
        
        //Check to see if we hit a wall
        if(this.xPosition < this.LEFT_BOUNDARY)   //hit left wall
        {
            //get next color index and set the color
            this.setNextColor();

            this.xPosition = this.LEFT_BOUNDARY;
            this.xSpeed = -1 * this.xSpeed;   //go into reverse      
            this.diameter *= 1.2; //get 20% larger
        }
        else if(this.xPosition + this.diameter > this.RIGHT_BOUNDARY) //hit right wall
        {
            //get next color index and set the color            
            this.setNextColor();

            this.xPosition = this.RIGHT_BOUNDARY - this.diameter;
            this.xSpeed = -1 * this.xSpeed;   //go into reverse
            this.diameter *= 0.75; //make 25% smaller

            
            //xSpeed = -1 * xSpeed + 40; // adding the constant 40 offsets the negative sign
                //xSpeed = -1 * xSpeed * 20; // gain speed by factor of 20x (ball seems to stick on two sides)
            //System.out.println(xSpeed);
        }
        
        if(this.yPosition < this.TOP_BOUNDARY)    //hit top wall
        {
            //get next color index and set the color
            this.setNextColor();

            this.yPosition = this.TOP_BOUNDARY;
            this.ySpeed = -1 * this.ySpeed;
        }
        else if(this.yPosition + this.diameter > this.BOTTOM_BOUNDARY) //hit bottom wall
        {
            //get next color index and set the color
            this.setNextColor();

            this.yPosition = this.BOTTOM_BOUNDARY - this.diameter;
            this.ySpeed = -1 * this.ySpeed;   //go into reverse
        }
    }
    
    /**
     * Moves the color index up, or cycle back to 0, then sets the color
     * to the color referenced in PRETTY_COLORS
     */
    private void setNextColor()
    {
        //get next color index and set the color
        this.colorIndex = (this.colorIndex + 1) % this.PRETTY_COLORS.length;
        this.color = this.PRETTY_COLORS[this.colorIndex];
    }
    
    /**
     * Gets the current x position of the ball
     * @return the x position of the ball
     */
    public int getX()
    {
        return (int) this.xPosition;
    }

    /**
     * Gets the current y position of the ball
     * @return the y position of the ball
     */
    public int getY()
    {
        return (int) this.yPosition;
    }
    
    /**
     * Gets the diamater of the ball
     * @return the diameter of the ball
     */
    public int getDiameter()
    {
        return this.diameter;
    }
    
    /**
     * Gets the current color of the ball
     * @return the color of the ball as a Color object
     */
    public Color getColor()
    {
        return this.getColorFromString(color);
    }
    
    /**
     * Determines whether this ball is touching (overlaps) with the given other ball.
     * @param other the other ball to check again
     * @return whether or not the two balls are touching
     */
    public boolean isTouching(Ball other)
    {
        double distance = Math.sqrt(
            (this.xPosition-other.xPosition)*(this.xPosition-other.xPosition) +
            (this.yPosition-other.yPosition)*(this.yPosition-other.yPosition)); //pythagorean theorem
            
        return distance < (this.diameter/2.0+other.diameter/2.0); //touching if distance is less than sum of the radii
    }
    
    /**
     * Adjusts our speed/direction as we bounce off another ball
     * @param other the ball we have bounced off
     */
    public void bounceOff(Ball other)
    {
        //reverse direction
        this.xSpeed = -1 * this.xSpeed;
        this.ySpeed = -1 * this.ySpeed;

        double distance = Math.sqrt(
            (this.xPosition - other.xPosition)*(this.xPosition-other.xPosition) +
            (this.yPosition - other.yPosition)*(this.yPosition-other.yPosition)); //pythagorean theorem

        double overlap = (this.diameter + other.diameter)/2.0 - distance;
        if(overlap > 0) //if we are still touching
        {
            System.out.println("bounce !" + overlap);
            //move us something approximating the distance away. This should mostly put us out of touch
            this.xPosition += Math.signum(this.xSpeed)*(overlap*Math.sqrt(2)/2);
            this.yPosition += Math.signum(this.ySpeed)*(overlap*Math.sqrt(2)/2);
        }
    }
    
    /**
     * Helper method for converting Strings to colors
     * DO NOT MODIFY
     */
    private Color getColorFromString(String c)
    {
        if(c.equals("blue"))
            return new Color(38,125,255);
        if(c.equals("cyan"))
            return new Color(38,255,255);
        if(c.equals("green"))
            return new Color(82,255,38);
        if(c.equals("magenta"))
            return new Color(255,38,168);
        if(c.equals("orange"))
            return new Color(255,168,38);
        if(c.equals("pink"))
            return Color.PINK;
        if(c.equals("red"))
            return new Color(255,38,38);
        if(c.equals("white"))
            return Color.WHITE;
        if(c.equals("yellow"))
            return new Color(212,255,38);
        return Color.BLACK; //return black otherwise
    }

    
    /****CONSTANTS FOR YOUR CONVENIENCE --- DO NOT MODIFY****/
    //convenience constants for court boundaries--these make life a bit easier
    private final int TOP_BOUNDARY = BallCourt.Y_CORNER;
    private final int LEFT_BOUNDARY = BallCourt.X_CORNER;
    private final int BOTTOM_BOUNDARY = BallCourt.Y_CORNER + BallCourt.COURT_HEIGHT;
    private final int RIGHT_BOUNDARY = BallCourt.X_CORNER + BallCourt.COURT_WIDTH;
    /**** END CONSTANTS ****/

}
