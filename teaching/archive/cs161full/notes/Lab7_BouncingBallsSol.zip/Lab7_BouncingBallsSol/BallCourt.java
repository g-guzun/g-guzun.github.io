import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * A class that represents an arena in which multiple balls can bounce!
 * 
 * @author Joel Ross & David
 */
public class BallCourt
{
    private BallCourtFrame frame; //a frame to show the animation in. DO NOT MODIFY
    private Ball[] balls; //an example
    
    /**
     * Creates a new BallCourt object.
     */
    public BallCourt(int numBalls)
    {
        if (numBalls < 1) {
            numBalls = 5;
        }

        this.balls = new Ball[numBalls]; //instantiate the array

        //instantiate each array element
        for (int i = 0; i < this.balls.length; i++) {
            this.balls[i] = new Ball();
        }
        
        frame = new BallCourtFrame(this); //create a frame to start animating this BallCourt
    }

    /**
     * Draws Balls in the frame
     */
    public void paintComponent(Graphics brush)
    {
        //loop through all the balls and set them to move
        for (int i = 0; i < balls.length; i++) {
            this.balls[i].move();
        }
        
        brush.setColor(Color.BLACK);
        brush.fillRect(0,0,COURT_WIDTH + 2*X_CORNER, COURT_HEIGHT + 2*Y_CORNER); //draw the black border
        brush.setColor(Color.LIGHT_GRAY);
        brush.fillRect(X_CORNER, Y_CORNER, COURT_WIDTH, COURT_HEIGHT); //make the court lighter

        //loop through all the balls and draw them in-place
        for (int i = 0; i < balls.length; i++) {
           brush.setColor(this.balls[i].getColor());
           brush.fillOval(this.balls[i].getX(), this.balls[i].getY(), this.balls[i].getDiameter(), this.balls[i].getDiameter());
        }
    }

    /**
     * Starts the animation
     */
    public void startAnimation() 
    { 
        frame.animator.start(); 
    }

    /**
     * Stops the animation
     */
    public void pauseAnimation()
    {
        frame.animator.stop();
    }

    
    /****CONSTANTS FOR YOUR CONVENIENCE --- DO NOT MODIFY****/
    //specify the size of the ballcourt
    public final static int X_CORNER = 25;
    public final static int Y_CORNER = 25;
    public final static int COURT_WIDTH = 400;
    public final static int COURT_HEIGHT = 400;
    /**** END CONSTANTS ****/

        

    /****FRAME AND ANIMATION STUFF --- DO NOT MODIFY****/
    private static class BallCourtFrame implements ActionListener
    {
        private JPanel drawing; //a JPanel that draws the court
        private Timer animator; //a timer to control animation
    
        private BallCourtFrame(final BallCourt court)
        {
            JFrame frame = new JFrame("Bouncing Balls"); //make the JFrame 
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            drawing = new JPanel(){public void paintComponent(Graphics g){court.paintComponent(g);}}; //anonymous class to actually do the drawing work
            drawing.setPreferredSize(new Dimension(2*BallCourt.X_CORNER+BallCourt.COURT_WIDTH, 2*BallCourt.Y_CORNER+BallCourt.COURT_HEIGHT));
            frame.add(drawing); //put the court drawing in the frame
            frame.pack(); //make everything the preferred size
            frame.setVisible(true); //show the frame
            
            animator = new Timer(30,this); //create a timer, with this object controlling it
            
            animator.start(); //start the animation!
        }
        
        /**
         * Method that controls the animation timer
         */
        public void actionPerformed(ActionEvent e) 
        { 
            drawing.repaint(); 
        }        
    }
}
