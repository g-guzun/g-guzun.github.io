
/**
 * This class represents an ORCA Card.
 *
 * @author David
 * @version 2/17/20
 */
public class OrcaCard
{
    private double balance;         //current balance on card
    private double tax_rate;        //tax rate
    private double taxes_paid;      //total taxes paid
    private double total_paid;      //total purchases
    private int trips_purchased;

    /**
     * Constructs an OrcaCard with zero balance.
     */
    public OrcaCard() {
        this.balance = 0;
        this.tax_rate = 0.065;
        this.taxes_paid = 0;
        this.total_paid = 0;
        this.trips_purchased = 0;
    }

    /**
     * Constructs an OrcaCard with a balance. Defaults to 6.5%
     * sales tax if the given tax rate is negative.
     * 
     * @param sales_tax a specified sales tax
     */
    public OrcaCard(double sales_tax) {
        this.balance = 0;
        this.tax_rate = 0.065;
        this.taxes_paid = 0;
        this.total_paid = 0;
        this.trips_purchased = 0;

        //ensure the given balance is a positive value
        if (sales_tax > 0) {
            this.tax_rate = sales_tax;
        }
    }

    /**
     * Adds the given amount to the balance. No effect if
     * the given amount is negative.
     * 
     * @param amount an amount to top up
     */
    public void topUp(double amount) {
        if (amount > 0) {
            this.balance += amount;
        }
    }

    /**
     * Attempts to buy a trip of the specified cost. Success if 
     * cost of trip (plus tax) can be purchased with the current
     * balance, and fail otherwise.
     * 
     * @param cost the cost of the trip.
     */
    public void buyTrip(double cost) {
        //calculate the tax
        double tax = cost * this.tax_rate;

        //can the trip be purchased with current balance?
        if (this.balance >= (tax + cost)) {
            this.balance -= (cost + tax);    //balance subtracts cost of trip plus tax
            this.taxes_paid += tax;          //running accumulation of taxes
            this.total_paid += cost;         //running accumulation of purchases
            this.trips_purchased++;          //update number of trips bought
            //print success message
            System.out.println("Success: Ticket purchased.  $"+ this.balance + " remaining");
        }
        else {
            //print fail message
            System.out.println("Fail: You cannot afford this trip.");
        }
    }

    /**
     * @return a string reporting the balance level of the card
     */
    public String balanceLevel() {
        double avgCost = this.getAverageTripCost();
        if (this.balance == 0) {
            return "Your card is empty! Top up immediately!";
        }
        else if (this.balance <= avgCost) {
            return "Your balance is low!";
        }
        else if (this.balance <= 2*avgCost) {
            return "Your balance is just enough.";
        }
        else if (this.balance <= 5*avgCost) {
            return "Your balance is sufficient!";
        }
        else {
            return "Your balance is high!";
        }
    }

    /**
     * @return the total taxes paid
     */
    public double getTax() {
        return this.taxes_paid;
    }

    /**
     * @return average trip cost
     */
    public double getAverageTripCost() {
        return this.total_paid / this.trips_purchased;
    }

    /**
     * Prints a summary of the card
     */
    public void printSummary() {
        System.out.println("$" + this.balance + " left after " + this.trips_purchased + " trip(s)");
        System.out.println(this.balanceLevel());
    }
}
