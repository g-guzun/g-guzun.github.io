
/**
 * Write a description of class Tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tester
{
    public static void main(String[] args)
    {
        //Q1: [5pts] The overloaded constructor that 
        //verifies the input value for the sales tax.
        System.out.println("--------- Q1 ---------");
        OrcaCard card1 = new OrcaCard(-2);        
        System.out.println("Expected: 0.065");
        System.out.println("Actual: " + card1.getTax());

        //Q2: The topUp() method must verify that the 
        //given amount is non-negative.
        System.out.println("\n--------- Q2 ---------");
        OrcaCard card2 = new OrcaCard();
        card2.topUp(-1);
        System.out.println("Expected: $0.0 left after 0 trip(s).");
        System.out.print("Actual: ");
        card2.printSummary();
        
        //Q3: The buyTrip() method adjusts your balance 
        //after purchasing a trip of the specified amount. 
        //Don't forget to add the tax. It must also verify 
        //that the trip of the given amount can be purchased, 
        //and if not, it should output an error message.
        System.out.println("\n--------- Q3 ---------");
        OrcaCard card3 = new OrcaCard();
        card3.topUp(1000);
        System.out.println("Expected: Success: Ticket purchased.  $733.75 remaining");
        System.out.print("Actual: ");
        card3.buyTrip(250);

        System.out.println("Expected: Fail: You cannot afford this trip.");
        System.out.print("Actual: ");
        card3.buyTrip(800);

        //Q4: The getTax() method is properly implemented.
        System.out.println("\n--------- Q4 ---------");
        System.out.println("Expected: 16.25");
        System.out.println("Actual: " + card3.getTax());
        
        //Q5: The getAverageTripCost() method is properly implemented.
        System.out.println("\n--------- Q5 ---------");
        System.out.println("Expected: 250.0");
        System.out.println("Actual: " + card3.getAverageTripCost());
    }
}
