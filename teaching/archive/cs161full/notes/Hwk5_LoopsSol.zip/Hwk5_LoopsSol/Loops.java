
/**
 * Solutions to Loop exercises
 *
 * @author David
 * @version 3/26/2020
 */
public class Loops {

    /**
     * Multiplies two numbers together (handles negatives)
     * @param A First number
     * @param B Second number
     * @return Their product
     */
    public int multiply(int A, int B) {
        // checks if B is negative
        if (B < 0) {
            B = -B;
            A = -A;
        }

        int product = 0;
        for (int i = 0; i < B; i++) {
            product += A;
        }
        return product;
    }

    /**
     * Prints a right triangle (see below) of height and base of size n, with 
     * the straight edge facing east.
     * @param n Size
     */
    public void printTriangle(int n) {
        String str = "";
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (j < n-i-1) {
                    str += " ";
                }
                else {
                    str += "*";
                }
            }
            str += "\n";
        }
        System.out.println(str);
    }

    /**
     * Reveals each number (from 1 to n) on a separate line.
     * @param n positive integer
     */
    public void reveal(int n) {
        String s = "";
        //outer loop handles the printing of each line
        //counts from 1 to n (inclusive)
        for (int line = 0; line <= n; line++) {
            //inner loop counts from 1 to n (inclusive) and compares
            //its counter to the line number. Only L numbers are printed
            //out, when you're on the Lth line.
            for (int j = 1; j <= n; j++) {
                if (j > line) {
                    s += "-";
                }
                else {
                    s += j;
                }
            }
            System.out.println(s);
            s = "";
        }
    }
    
    /**
     * Prints out the first n prime numbers.
     * @param n A non-negative integer
     */
    public void findPrimes(int n) {
        int current = 2;    // this is the current number we're testing for primality
        int numFound = 0;   // this is the number of primes found so far
        
        while (numFound < n) {
            if (this.isPrime(current)) {
                // got one!
                System.out.println(current);
                numFound++;
            }
            
            // test next number
            current++;
        }
    }
    
    /**
     * Determines if a given number is prime
     * @param n A positive number
     * @returns true if n is prime, false otherwise.
     */
    private boolean isPrime(int n) {
        if (n < 2) {
            return false;
        }
        int divisor = n-1;
        while (n % divisor != 0) {
            divisor--;
        }
        return (divisor == 1);
    }
}
