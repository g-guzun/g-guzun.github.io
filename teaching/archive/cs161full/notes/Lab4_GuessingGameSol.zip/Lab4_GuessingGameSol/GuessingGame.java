import java.util.Random;
/**
 * This is a computer version of the popular Guessing Game!
 * 
 * @author David Chiu
 * @version 02/23/2015
 */
public class GuessingGame {
    private int secretNumber;   //holds the secret number
    private int numGuesses;     //counts the number of guesses made
    private boolean gameOver;   //records whether the game is over

    /**
     * Constructs a default guessing game: a number between 1 and 50
     * .
     */
    public GuessingGame() {
        // generate secret number
        Random rng = new Random();
        this.secretNumber = rng.nextInt(50) + 1;
        
        this.numGuesses = 0;
        this.gameOver = false;
        System.out.println("Welcome to the Guessing Game!");
        System.out.println("I picked a number between 1 and 50. Try and guess!");
    }

    /**
     * Constructor a guessing game with a number between 1 and the given upper bound.
     * 
     * @param upper The upper bound for the secret number
     */
    public GuessingGame(int upper) {
        // generate secret number
        Random rng = new Random();
        if (upper <= 0) {
            //given input is too low; initiating with 50
            this.secretNumber = rng.nextInt(50) + 1;
        }
        else {
            //create a random number in range of [1,upper]
            this.secretNumber = rng.nextInt(upper) + 1;
        }

        this.numGuesses = 0;
        this.gameOver = false;
        System.out.println("Welcome to the Guessing Game!");
        System.out.println("I picked a number between 1 and " + upper + ". Try and guess!");
    }
    
    /**
     * Allows the user to guess the secret number if the game is not
     * over, or if the guess-limit has not been reached.
     * 
     * @param  guess   A number that the user guessed
     */
    public void guess(int guess) {
        if (this.gameOver) {   //game is over!
            System.out.println("Game over!");
            System.out.println("You already guessed that the secret number was " + 
                secretNumber + " in " + numGuesses + " tries");
        }
        else {    //game is not over
            this.numGuesses++;    //they made a guess, increment the count
            System.out.println("You guessed " + guess + ".");

            //they got it!
            if (guess == this.secretNumber) {
                this.gameOver = true;
                System.out.println("Congratulations, you figured it out in " + 
                    numGuesses + " guesses!");

                //print insult or compliment
                if (numGuesses == 1) {
                    System.out.println("All luck!");
                }
                else if (numGuesses <= 4) {
                    System.out.println("Amazing!");
                }
                else if (numGuesses <= 6) {
                    System.out.println("Hey... Not bad!");
                }
                else if (numGuesses == 7) {
                    System.out.println("I've seen better.");
                }
                else if (numGuesses <= 9) {
                    System.out.println("Stop playing.");
                }
                else {
                    System.out.println("Worst performance of all time.");
                }
            }
            else {  //user must've been wrong
                // first, let's check to see how far off they were
                int difference = abs(guess - secretNumber);

                // now tell them how warm they are based on that difference
                if (difference == 1) {
                    System.out.println("Your guess is scalding hot!");
                }
                else if (difference == 2) {
                    System.out.println("Your guess is extremely warm!");
                }
                else if (difference == 3) {
                    System.out.println("Your guess is very warm!");
                }
                else if (difference <= 5) {
                    System.out.println("Your guess is warm!");
                }
                else if (difference <= 8) {
                    System.out.println("Your guess is cold!");
                }
                else if (difference <= 13) {
                    System.out.println("Your guess is very cold!");
                }
                else if (difference <= 20) {
                    System.out.println("Your guess is extremely cold!");
                }
                else {
                    System.out.println("Your guess is icy freezing miserably cold!");
                }

                //finally, tell them to go higher or lower
                if (guess > secretNumber) {
                    System.out.println("Try a little lower.");
                }
                else {
                    System.out.println("Try a little higher.");
                }
            }
        }
    }
    
    /**
     * Determine and return the absolute value of the given integer
     * @param x the number to take the absolute value of
     * @return the absolute value of x
     */
    public int abs(int x) {
        if (x < 0) {
            x = -x;
        }
        return x;
    }
}
