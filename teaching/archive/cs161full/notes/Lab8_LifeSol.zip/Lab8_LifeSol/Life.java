import java.util.Random;

/**
 * A class that represents a board for Conway's Life.
 * 
 * @author David 
 * @version 04/17/15
 */

public class Life
{
    private final int DEFAULT_SIZE = 25;    //default height & width of the board
                                            //if bad dimensions are given
    private Cell[][] board;

    /**
     * A constructor for a new Life game dimensions must be square!
     * Height and width must be at least 2.
     * If dimensions are not equal or if dimensions are too small,
     * then a N x N board is created, where N is the default size of the board.
     * 
     * @param height the height of the board
     * @param width the width of the board
     */
    public Life(int height, int width)
    {
        //checking input-integrity
        if (height != width || height < 2 || width < 2)
        {
            height = DEFAULT_SIZE;
            width = DEFAULT_SIZE;
        }
        
        board = new Cell[height][width];    //instantiate an empty board
        //fillRandom();                       //fill each location in the board with a random Cells
        fillSpaceship();
    }

    /**
     * Updates the board for the next generation
     */
    public void nextGeneration()
    {
        //create temporary board of same dimensions
        int height = board.length;
        int width = board[0].length;
        Cell[][] tmp = new Cell[height][width];

        for (int x = 0; x < height; x++)
        {
            for (int y = 0; y < width; y++)
            {
                //count neighbors for Cell at (x,y)
                int neighbors = countLivingNeighbors(x,y);
                
                if (isAlive(x,y))   //if current cell is alive then...
                {
                    if (neighbors < 2 || neighbors > 3)
                        tmp[x][y] = new Cell(false);
                    else
                        tmp[x][y] = new Cell(true);
                }
                else  //current cell is dead
                {
                    //bring the dead cell to life if it has 3 neighbors
                    if (neighbors == 3)
                        tmp[x][y] = new Cell(true);
                    else
                        tmp[x][y] = new Cell(false);
                }
            }
        }
        
        //replace board with the new board!
        board = tmp;
    }

    /**
     * Returns whether or not a cell is alive.
     * @param y the y coord of the cell
     * @param x the x coord of the cell
     * @return whether the cell is alive or not
     */
    public boolean isAlive(int x, int y)
    {
        return board[x][y].isAlive();
    }

    /**
     * Returns the number of living neighbors next to a cell.
     * @param y the y coord of the cell
     * @param x the x coord of the cell
     * @return the number of living neighbors next to the cell
     */
    public int countLivingNeighbors(int x, int y)
    {
        int neighbors = 0;
        int height = board.length;
        int width = board[0].length;

        //examine all 8 neighbors' coordinates
        for (int i = x-1; i <= x+1; i++)
        {
            for (int j = y-1; j <= y+1; j++)
            {
                //check edges of the board and don't count itself
                if (!(x == i && y == j) && i >= 0 && i < height && j >= 0 && j < width)
                {
                    //found a live neighbor!
                    if (isAlive(i,j)) {
                        neighbors++;
                    }
                }
            }
        }
        return neighbors;
    }

    /**
     * Fills the board with random cells
     */
    public void fillRandom()
    {
        Random rng = new Random();
        for (int i=0; i<board.length; i++)
        {
            for (int j=0; j<board[i].length; j++)
            {
                board[i][j] = new Cell(rng.nextBoolean());
            }
        }
    }

    public void fillSpaceship()
    {
        for (int i=0; i<board.length; i++)
        {
            for (int j=0; j<board[i].length; j++)
            {
                board[i][j] = new Cell(false);
            }
        }

        board[0][2].enable();
        board[1][3].enable();
        board[2][1].enable();
        board[2][2].enable();
        board[2][3].enable();

        
//         board[1][12].enable();
//         board[2][11].enable();
//         board[3][11].enable();
//         board[3][12].enable();
//         board[3][13].enable();
//         
// 
//         board[3][12].enable();
//         board[4][11].enable();
//         board[5][11].enable();
//         board[5][12].enable();
//         board[5][13].enable();        
        
    }
}
