
/**
 * Write a description of class Cell here.
 * 
 * @author David
 * @version 04/17
 */
public class Cell
{
    private boolean isAlive;

    /**
     * Constructor for objects of class Cell
     * @param startAlive An initial value for the state of Cell
     */
    public Cell(boolean startAlive)
    {
        isAlive = startAlive;
    }

    /**
     * @return whether this Cell is alive
     */
    public boolean isAlive()
    {
        return isAlive;
    }
    
    /**
     * Disable this Cell
     */
    public void disable()
    {
        isAlive = false;
    }
    
    /**
     * Bring this Cell to life
     */
    public void enable()
    {
        isAlive = true;
    }
}
