import java.util.ArrayList;

/**
 * Objects of this class can parse tweets and record statistics.
 * 
 * @author David Chiu
 * @version 03/05/2015
 */
public class TweetProcessor
{
    private int tweetCount;
    private int termCount;
    private int hashtagCount;
    private int mentionCount;
    private int characterCount;
    private ArrayList<String> history;

    /**
     * Default constructor for objects of class TweetProcessor
     */
    public TweetProcessor()
    {
        this.history = new ArrayList<>();
        this.reset();
    }

    /**
     * Resets all fields
     */
    public void reset()
    {
        this.tweetCount = 0;
        this.termCount = 0;
        this.hashtagCount = 0;
        this.mentionCount = 0;
        this.characterCount = 0;
        this.history.clear();
    }

    /**
     * @return tweet statistics
     */
    public String toString()
    {
        String str = "Tweets: " + this.tweetCount + "\n";
        str += "Terms: " + this.termCount + "\n";
        str += "Characters per tweet: " + ((double) this.characterCount) / this.tweetCount  + "\n";
        str += "Hashtags: " + this.hashtagCount + "\n";
        str += "Mentions: " + this.mentionCount + "\n";

        //print hashtag history
        //if none has been found, print out a message stating so
        String history_str = "";
        if (!history.isEmpty()) {
            for (int i = 0; i < this.history.size(); i++) {
                history_str += this.history.get(i) + " ";
            }
        }
        else {
            history_str = "(no hashtags found)";
        }
        str += "History ("+ this.history.size() +"): " + history_str;
        return str;
    }

    /**
     * @param a specified term from a tweet
     * @return whether given term is a #hashtag
     */
    public boolean isHashtag(String term)
    {
        //only check if term is at least 2 letters long
        if (term != null && term.length() > 1) {
            return term.substring(0,1).equals("#");
        }
        return false;
    }

    /**
     * @param a specified term from a tweet
     * @return whether given term is a @mention
     */
    public boolean isMention(String term)
    {
        //only check if term is at least 2 letters long
        if (term != null && term.length() > 1) {
            return term.substring(0,1).equals("@");
        }
        return false;
    }
    
    /**
     * Process a tweet
     * @param tweet
     */
    public void processTweet(String tweet)
    {
        if (tweet != null && !tweet.equals("")) {
             //increment tweet count
            this.tweetCount++;
            
            //increment character count
            this.characterCount += tweet.length();
           
            // deal with #hashtags and @mentions
            // loop through each term in the tweet
            String[] terms = tweet.split(" ");
            for (int i = 0; i < terms.length; i++) {
                // increment term count
                this.termCount++;

                if (this.isHashtag(terms[i])) {      // term is a hashtag!
                    this.hashtagCount++;

                    //add the hashtag to history if it's new
                    if (this.history.indexOf(terms[i].toLowerCase()) == -1) {
                        this.history.add(terms[i].toLowerCase());   
                    }
                }
                else if (this.isMention(terms[i])) { // term is a mention!
                    this.mentionCount++;
                }
            }
        }
    }
}
