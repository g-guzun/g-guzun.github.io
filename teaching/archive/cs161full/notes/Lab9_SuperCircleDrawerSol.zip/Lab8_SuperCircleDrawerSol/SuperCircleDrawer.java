import java.util.ArrayList;
import java.util.Random;

/**
 * Objects of this class can manage an unlimited number of Circles
 * 
 * @author David Chiu
 * @version 3/10/2015
 */
public class SuperCircleDrawer
{
    private ArrayList<Circle> circleCollection;

    /**
     * Constructs a super circle drawer that manages a specified number of circles, initially.
     */
    public SuperCircleDrawer(int numCircles) {
        Random rng = new Random();

        //create the given number of circles
        this.circleCollection = new ArrayList<>();
        for (int i = 0; i < numCircles; i++) {
            Circle c = new Circle(rng.nextInt(100)+1);  //diameter of 1 to 100
            c.moveTo(rng.nextInt(601), rng.nextInt(801));   //random location
            this.circleCollection.add(c);    //add to collection
        }        
    }

    /**
     * Adds a given Circle to the collection
     */
    public void addCircle(Circle newCircle) {
        if (newCircle != null) {
            newCircle.makeVisible();
            this.circleCollection.add(newCircle);
        }
    }
    
    /**
     * Draws all Circles in the collection
     */
    public void drawCircles() {
        for (int i = 0; i < this.circleCollection.size(); i++) {
           this.circleCollection.get(i).makeVisible();
        }
    }

    /**
     * Erases all Circles in the collection
     */
    public void eraseCircles() {
        for (int i = 0; i < this.circleCollection.size(); i++) {
            this.circleCollection.get(i).makeInvisible();
        }
    }

    /**
     * Removes smallest circle from the collection
     */
    public void removeSmallest() {
        if (this.circleCollection.size() > 0) {
            //identify the smallest circle
            Circle smallest = this.circleCollection.get(0);
            for (int i = 1; i < this.circleCollection.size(); i++) {
                //found a smaller one!
                if (smallest.getDiameter() > this.circleCollection.get(i).getDiameter()) {
                    smallest = this.circleCollection.get(i);
                }
            }
            smallest.makeInvisible();
            this.circleCollection.remove(smallest);
        }
    }
    
    /**
     * Replaces one circle with another
     * @param c1 the circle to be replaced
     * @param c2 the replacement circle
     */
    public void replace(Circle c1, Circle c2) {
        if (this.circleCollection.size() > 0) {
            //search for c1
            int index = this.circleCollection.indexOf(c1);
            if (index > -1) {
                c1.makeInvisible(); //erase the old circle
                this.circleCollection.set(index, c2);    //replace it in the collection
                c2.makeVisible();   //draw the new circle
            }
        }
    }

    /**
     * Replaces the largest circle in the collection with the given circle
     * @param c the replacement circle
     */
    public void replaceLargest(Circle c) {
        if (this.circleCollection.size() > 0) {
            //identify the largest circle
            Circle largest = this.circleCollection.get(0);
            for (int i = 1; i < this.circleCollection.size(); i++) {
                //found a larger one!
                if (largest.getDiameter() < this.circleCollection.get(i).getDiameter()) {
                    largest = this.circleCollection.get(i);
                }
            }
            this.replace(largest, c);
        }
    }
    
    
    /**
     * Doubles all Circles' sizes
     */
    public void doubleAllDiameters() {
        for (int i = 0; i < this.circleCollection.size(); i++) {
            Circle c = this.circleCollection.get(i);
            c.changeSize(c.getDiameter() * 2);
        }
    }

    /**
     * Causes Circles larger than 30 diameter to be drawn. Hide all others.
     */
    public void drawLargeCircles() {
        this.eraseCircles(); //hide all circles initially

        for (int i = 0; i < this.circleCollection.size(); i++) {
            if (this.circleCollection.get(i).getDiameter() > 30) {
                this.circleCollection.get(i).makeVisible();
            }
        }
    }

    /**
     * Draw largest Circle in the Collection
     */
    public void drawLargestCircle() {
        //ensure there's at least one circle in the collection
        if (this.circleCollection.size() > 0) {
            this.eraseCircles(); //hide all circles

            //find the largest Circle
            //initially, the largest is just the first circle in the collection
            Circle largestCircle = this.circleCollection.get(0);
            for (int i = 1; i < this.circleCollection.size(); i++) {
                //found a larger Circle
                if (largestCircle.getDiameter() < this.circleCollection.get(i).getDiameter()) {
                    largestCircle = this.circleCollection.get(i);
                }
            }
            //at this point, all Circles are hidden
            //draw the largest
            largestCircle.makeVisible();
        }
    }
}
