/**
 * A class representing a TurtleDrawer
 * 
 * @author David
 * @version 03/10/2015
 */
public class TurtleDrawer
{    
    Turtle pen;

    /**
     * Creates a turtle with a black pen, lowered.
     */
    public TurtleDrawer()
    {
        pen = new Turtle();
        pen.setPenColor("black");
        pen.penDown();
    }

    /**
     * Draws nested polygons
     */
    public void drawMyPattern()
    {
        int numSides = 6;
        double sideLength = 100;
        double factor = 1.0;
        int i = 0;
        while (factor > 0)
        {
            //alternate colors between blue and red
            if (i % 2 == 0)
            {
                drawPolygon(sideLength*factor, numSides, "red");
            }
            else
            {
                drawPolygon(sideLength*factor, numSides, "blue");
            }
            factor -= 0.2;
            i++;
        }
    }

    /**
     * Draws a grid, in which each cell is of a given size.
     */
    public void drawGrid(double cellSize, int numRows, int numCols, String color)
    {
        //count of rows we need to draw
        for (int i = 0; i < numRows; i++)
        {
            //count of triangles drawn in this row
            for (int j = 0; j < numCols; j++)
            {
                //draw one hexagon
                drawPolygon(cellSize, 4, color);  

                //move pen in position to draw next triangle
                pen.penUp();
                pen.forward(cellSize);
                pen.penDown();
            }

            //move turtle in position for next row
            pen.penUp();
            pen.left(90);
            pen.forward(cellSize);
            pen.left(90);
            pen.forward(cellSize*numCols);
            pen.right(180);
        }
    }

    /**
     * Draw Triangle
     * @param sideLength Length of each edge
     */
    public void drawTriangle(double sideLength)
    {
        drawPolygon(sideLength, 3, "black");
    }

    /**
     * Draws a polygon
     * @param sideLength Length of each edge
     * @param numSides Number of sides in this polygon
     * @param color Color of polygon
     */
    public void drawPolygon(double sideLength, int numSides, String color)
    {
        //we only want to draw the shape if there are at least three sides
        if (numSides >= 3)
        {

            pen.penDown();
            pen.setPenColor(color);

            for (int side = 0; side < numSides; side++)
            {
                pen.forward(sideLength);
                pen.left(360.0/numSides);
            }
        }
    }
    
    /**
     * Draws a snake pattern
     * @param length
     * @param width
     * @param depth
     * @param color
     */
    public void drawSnake(double length, double width, double depth, String color)
    {
        pen.penDown();
        pen.setPenColor(color);

        int numRepeat = (int) (length / (2*depth));
        for (int i = 0; i < numRepeat; i++)
        {        
            pen.forward(width);
            pen.left(90);
            pen.forward(depth);
            pen.left(90);
            pen.forward(width);
            pen.right(90);
            pen.forward(depth);
            pen.right(90);
        }
        
        //finish off last edge
        pen.forward(width);
    }

    
    
    /**
     * Draws a zigzag
     * @param length Length of the line
     * @param width Width of zigzag
     * @param zigColor Color of the vertical (zig lines)
     * @param zagColor Color of thed diagonal (zag lines)
     */
    public void drawZigzag(double length, double width, String zigColor, String zagColor)
    {
        if (width <= length)
        {
            //a necessary first turn
            pen.left(90);
            pen.penDown();

            double hypotenuse = Math.sqrt(Math.pow(width,2)*2); //distance of the diagonal
            double numZigzags = length / width;    //compute the number of zigzags that we need to draw
            for (int i = 0; i < numZigzags; i++)
            {
                pen.setPenColor(zigColor);
                pen.forward(width);
                pen.right(135);
                pen.setPenColor(zagColor);
                pen.forward(hypotenuse);
                pen.left(135);
            }

            //finish with one last zig
            pen.setPenColor(zigColor);
            pen.forward(width);
        }
    }

    /**
     * Draws a dashed line
     * @param length a given length
     * @param interval the dash interval
     */
    public void drawDashedLine(double length, double dashLength, String color)
    {
        pen.setPenColor(color);

        double numDashes = length / dashLength;
        int dashCount = 0;
        while (dashCount < numDashes)
        {
            if (dashCount % 2 == 0)
            {
                pen.penDown();
            }
            else
            {
                pen.penUp();
            }
            pen.forward(dashLength);
            dashCount += 1;
        }
    }
    
}
