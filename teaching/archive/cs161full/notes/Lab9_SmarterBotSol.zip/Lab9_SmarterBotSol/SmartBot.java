import java.util.HashMap;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * A little smarter chatbot
 *
 * @author David
 * @version 10/24/2017
 */
public class SmartBot
{
    private Random rng;
    private ArrayList<String> responses;
    private HashMap<String,String> responseMap;
    private SynonymMapper synMap;

    /**
     * Creates a new chat bot
     */
    public SmartBot()
    {
        rng = new Random();
        responses = new ArrayList<>();
        fillSnarkyResponses();
        
        responseMap = new HashMap<>();
        fillResponseMap();

        synMap = new SynonymMapper();
    }

    public void start()
    {
        printWelcome();

        Scanner keyboard = new Scanner(System.in);  // Used to get keyboard input
        String user_input;                          // Stores their response

        do {
            user_input = keyboard.nextLine();       // Get user input
            
            if (!user_input.equalsIgnoreCase("bye")) {
                printResponse(user_input); 
            }
        } while (!user_input.equalsIgnoreCase("bye"));
        printGoodbye();
    }
    
    /**
     * Fill a set of snarky responses
     */
    private void fillSnarkyResponses()
    {
        responses.add("Say, do you like cats?");
        responses.add("No one has ever complained about this before.");
        responses.add("You're not making any sense. Could you ask in a different way?");
        responses.add("I just Googled it. It doesn't know either.");
        responses.add("Calm down, I don't want to argue.");
    }
    
    /**
     * Fill the response map
     */
    private void fillResponseMap()
    {
        responseMap.put("crash", "It never crashes on our end. Must be something you're doing!");
        responseMap.put("wifi", "Have you tried resetting your router?");
        responseMap.put("network", "Have you tried resetting your router?");
        responseMap.put("slow", "I recommend installing more memory!");
        responseMap.put("heat", "One of your programs is probably stuck in an infinite loop. Terminate the offending program.");
        responseMap.put("hot", "One of your programs is probably stuck in an infinite loop. Terminate the offending program.");
        responseMap.put("bug", "It's not a bug; it's a feature!");
        responseMap.put("thanks", "You're welcome. Type 'bye' if you're satisfied, or ask another question.");
    }
    
    
    /**
     * Prints a welcome message
     */
    private void printWelcome()
    {
        System.out.println("Tech support! How can I help?");
        System.out.println("Type 'bye' to end this session.");
    }

    /**
     * Prints good bye message
     */
    private void printGoodbye()
    {
        System.out.println("Glad I was able to help. Bye!");
    }
    
    /**
     * Print a random snarky response
     */
    private void printSnarkyResponse()
    {
        // Get a random response from the list
        String resp = responses.get(rng.nextInt(responses.size()));
        System.out.println(resp);
    }
    
    /**
     * Print a response, based on their question
     * @param question  a question from the user
     */
    private void printResponse(String question)
    {
        // Split their question into words
        String[] words = question.split(" ");
        
        // Loop through each word and check to see if it's a keyword!
        for (int i = 0; i < words.length; i++)
        {
            // Keyword is found in the map!
            String rootWord = synMap.rootSynonym(words[i].toLowerCase());
            if (responseMap.containsKey(rootWord))
            {
                String resp = responseMap.get(rootWord); // Get the response using the keyword!
                System.out.println(resp);
                return; //terminate the void method
            }
        }
        
        // Keyword is not in the map; just generate a snarky response!
        printSnarkyResponse();
    }
}