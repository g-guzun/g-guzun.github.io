import java.util.HashMap;
import java.util.Set;

/**
 * SynonymMapper instances map input words (strings) to a common
 * "root synonym" if the input word is known, 
 */
public class SynonymMapper
{
    // A map from input words to their "root synonym".  For example,
    // the keys "bugs" and "buggy" might each map to the root word 
    // "bug", etc.
    private HashMap<String, String> synonymMap;
    
    /**
     * Create the HashMap, and call fillSynonyms() to add all
     * of the entries.
     */
    public SynonymMapper()
    {
        synonymMap = new HashMap<String, String>();
        fillSynonyms();
    }
    
    /**
     * Takes a word (string) as input, and returns the corresponding
     * root word from the map, if the input is known.  If we don't 
     * have an entry for the input word, we return the word itself.
     * 
     * @param word  The input word whose root we're after
     * @return  The corresponding root if found, else the input word.
     */
    public String rootSynonym(String word)
    {
        String synonym = synonymMap.get(word);
        if (synonym == null)
        {
            return word;
        }
        else
        {
            return synonym;
        }
    }
    
    /**
     * Add entries to the synonym map.
     */
    private void fillSynonyms()
    {        
        synonymMap.put("crashed", "crash");
        synonymMap.put("crashes", "crash");
        synonymMap.put("crashing", "crash");
        synonymMap.put("wifi", "network");
        synonymMap.put("internet", "network");
        synonymMap.put("heat", "hot");
        synonymMap.put("scalding", "hot");
        synonymMap.put("burning", "hot");
        synonymMap.put("buggy", "bug");
        synonymMap.put("bugs", "bug");
        synonymMap.put("sluggish", "slow");
        synonymMap.put("crawling", "slow");
    }
    
    /**
     * @returns a string containing the synonyms and their roots
     */
    public String toString()
    {
        String str = "";
        Set<String> synonymSet = synonymMap.keySet();
        for (String synonym : synonymSet) {
            str += synonym + "\t" + synonymMap.get(synonym) + "\n";
        }
        return str;
    }
}
