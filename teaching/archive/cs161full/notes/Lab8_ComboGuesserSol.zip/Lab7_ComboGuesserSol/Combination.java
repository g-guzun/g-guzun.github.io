import java.util.Random;

/**
 * This class represents a combination, which is a sequence of N integers.
 * 
 * @author David 
 * @version 11/04/2015
 */

public class Combination
{
    private Random rng;     
    private int[] sequence; //holds the secret integer sequence
    private int length;     //length of the secret sequence
    private int max;        //the upper bound of each integer in the sequence
    
    public Combination(int inLength, int inMax)
    {
        //initialize the fields
        this.rng = new Random();
        this.length = inLength;
        this.max = inMax;

        //instantiate the integer array field with a legal length
        this.sequence = new int[length];
        
        //randomly assign a number to each place in the sequence
        for (int i = 0; i < this.length; i++) {
            this.sequence[i] = this.rng.nextInt(this.max+1);
        }
    }

    /**
     * Setter method for combination. 
     * 
     * @param index The given index
     * @param value the given value
     */
    public void setValue(int index, int value)
    {
        //The given index must be valid, and the given value must be within range.
        if (index >= 0 && index < this.length && value >= 0 && value <= this.max) {
            this.sequence[index] = value;
        }
    }
    
    /**
     * @return true if combination is same as given Combination instance, false otherwise.
     */
    public boolean equals(Combination other)
    {
        // For two combinations to be equal, their string
        // representations must be the same.         
        String my_str = this.toString();             // The current combination's string representation
        String other_str = other.toString();    // The other combination's string representation
        return my_str.equals(other_str);        // Why not: return my_str == other_str;  ?
    }
    
    /**
     * @return The the secret integer sequence of the current Combination object
     */
    public int[] getSequence()
    {
        return this.sequence;
    }
    
    /**
     * @return a string representation of the combination
     */
    public String toString()
    {
        String str = "[";
        for (int i = 0; i < this.length; i++) {
            str += this.sequence[i];
            
            //concatenate the comma if we're not on the last element
            if (i < this.length - 1) {
                str += ", ";
            }
        }
        str += "]";
        return str;
    }

}