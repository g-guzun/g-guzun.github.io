import java.util.Random;

/**
 * Write a description of class ComboGuesser here.
 * 
 * @author David
 * @version 11/4/2015
 */
public class ComboGuesser
{
    private Combination key;
    private int length;
    private int max;

    /**
     * Constructor for objects of class ComboGuesser
     * @param inLength  The length of the combination
     * @param inMax     The upper bound of numbers
     */
    public ComboGuesser(int inLength, int inMax) {
        this.length = inLength;
        this.max = inMax;
        this.key = new Combination(inLength, inMax);
    }

    /**
     * Constructor for objects of class ComboGuesser
     * @param inLength  The length of the combination
     * @param inMax     The upper bound of numbers
     * @param inKey     A given key to guess
     */
    public ComboGuesser(int inLength, int inMax, Combination inKey) {
        this.length = inLength;
        this.max = inMax;
        this.key = inKey;
    }

    /**
     * Attempts to guess the combination key by repeatedly generating
     * new random combinations. Records and reports the number of guesses taken.
     */
    public void guessCombo() {
        Combination myGuess = new Combination(this.length, this.max);
        long guessCount = 1;
        
        // Sentinel condition: keep looping if we haven't guessed it!
        while (!myGuess.equals(this.key)) {
            myGuess = new Combination(this.length, this.max);
            guessCount++;
        }

        //got out of loop, must've guessed right
        System.out.println("It took " + guessCount + 
            " guesses to guess " + myGuess.toString());
    }
}
