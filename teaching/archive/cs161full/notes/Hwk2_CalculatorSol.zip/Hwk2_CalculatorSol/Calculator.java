/**
 * This class implements a basic calculator with one memory storage.
 * 
 * @author David Chiu
 * @version 02/23/2015
 */
public class Calculator
{
    //instance variables (fields)
    private int value;  //current value of the calculator
    private int mem;    //calculator memory
    
    /**
     * Default constructor sets current value and memory to 0
     */
    public Calculator()
    {
        this.value = 0;
        this.mem = 0;
    }

    /**
     * Constructor sets current value to given input
     * @param init_value The initial value given to the calculator
     */
    public Calculator(int initValue)
    {
        this.value = initValue;
        this.mem = 0;
    }

    /**
     * Performs add operation
     * @param addend Value to add
     */
    public void add(int addend)
    {
        int oldValue = this.value;
        this.value += addend;
        System.out.println(oldValue + " + " + addend + " = " + this.value);
    }
    
    /**
     * Performs subtract operation
     * @param subtrahend Value to be subtracted
     */
    public void subtract(int subtrahend)
    {
        int oldValue = this.value;
        this.value -= subtrahend;
        System.out.println(oldValue + " - " + subtrahend + " = " + this.value);
    }

    /**
     * Performs multiply
     * @param val Value to multiply
     */
    public void multiply(int multiplier)
    {
        int old_value = this.value;
        this.value *= multiplier;
        System.out.println(old_value + " * " + multiplier + " = " + this.value);
    }
    
    /**
     * Performs division
     * @param val Divisor
     */
    public void divide(int divisor)
    {
        if (divisor == 0) {   //can't divide by zero
            this.value = 0;  //clear value to zero
            System.out.println("Error: division by zero -- value cleared.");
        }
        else {            //divisor is not zero, so carry out operation
            //check for lossy precision: remainder exists?
            if (this.value % divisor != 0) {
                System.out.println("Warning: division resulted in loss of precision");
            }

            //carry out division and print out
            int oldValue = this.value;
            this.value = this.value / divisor;
            System.out.println(oldValue + " / " + divisor + " = " + this.value);
        }
    }
    
    /**
     * Squares the current value
     */
    public void square()
    {
        this.multiply(this.value);    //just call multiply with the current value!
    }
    
    /**
     * Stores current value in memory
     */
    public void store()
    {
        this.mem = this.value;
        System.out.println(this.value + " --> mem");
    }
    
    /**
     * Recalls value from memory
     */
    public void recall()
    {
        this.value = this.mem;        
        System.out.println("mem --> " + this.value);
    }

    /**
     * Getter for current value
     * @return current value
     */
    public int getValue()
    {
        return this.value;
    }

    /**
     * Swaps the values of memory and current value
     */
    public void exchange()
    {
        int tmp = this.mem;  //temporary variable to store current memory's contents
        this.mem = this.value;    //current memory gets overwritten
        this.value = tmp;    //display value gets old memory's contents
        System.out.println(this.mem + " <--> " + this.value);
    }
    
    /**
     * Take the square root.
     */
    public void squareRoot()
    {
        if (this.value >= 0) { //only take square root if value is non-negative
            int oldValue = this.value;
            value = (int) Math.sqrt(this.value); //need to cast into an int, since Math.sqrt() returns double
            System.out.println("squareRoot(" + oldValue + ") = " + this.value);

        }
        else {
            this.value = 0;
            System.out.println("Error: square root of negative value -- value cleared");
        }
    }
}