
/**
 * This class allows us to manage two Robots at once!
 * 
 * @author David
 * @version 12/8/2016
 */
public class RobotPair
{
    private Robot bot1;
    private Robot bot2;

    /**
     * Constructs an object which holds a pair of Robots
     */
    public RobotPair()
    {
        //instantiate the Robots
        this.bot1 = new Robot();
        this.bot2 = new Robot();

        //move them side-by-side
        this.bot1.moveTo(125,200);
        this.bot2.moveTo(275,200);
    }

    /**
     * Moves the Robot apart along the horizontal axis by a distance of 50.
     */
    public void moveApart()
    {
        this.bot1.moveHorizontal(-50);
        this.bot2.moveHorizontal(50);
    }

    /**
     *   Moves the Robot closer together along the horizontal axis by a distance of 50.
     */
    public void moveTogether()
    {
        this.bot1.moveHorizontal(50);
        this.bot2.moveHorizontal(-50);
    }

    /**
     * Makes the Robots do a special dance routine.
     */
    public void dance()
    {
        this.bot1.shakeHead();
        this.bot2.waveHand();
        this.moveApart();
        this.moveTogether();
        this.bot1.waveHand();
        this.bot2.shakeHead();
        this.moveTogether();
        this.moveApart();
    }
}
