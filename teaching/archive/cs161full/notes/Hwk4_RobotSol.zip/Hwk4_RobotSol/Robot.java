/**
 * This class provides users with a way to construct Robot objects
 * 
 * @author Joel Ross and David Chiu
 * @version 12/31/2014
 */
public class Robot
{
    private Square body;
    private Circle head;
    private Circle leftArm;
    private Circle rightArm;
    private Triangle feet;
    private int xCoord;     //the robot's location on x-axis
    private int yCoord;     //the robot's location on y-axis

    /**
     * Constructor for objects of class Robot
     */
    public Robot()
    {
        //create parts
        this.head = new Circle();
        this.leftArm = new Circle();
        this.rightArm = new Circle();
        this.body = new Square();
        this.feet = new Triangle();

        //get parts into right places       
        this.head.moveTo(235, 100);
        this.body.changeSize(60);
        this.body.moveTo(220,130);
        this.leftArm.changeSize(15);
        this.leftArm.moveTo(285, 130);
        this.rightArm.changeSize(15);
        this.rightArm.moveTo(200, 130);
        this.feet.moveTo(250, 190);

        //add correct colors to parts
        this.makeColorful();
        
        //save its current location
        this.xCoord = 200;
        this.yCoord = 100;
    }
    
    /**
     * Calling this method causes the robot to wave its left hand
     */
    public void waveHand() {
        this.leftArm.slowMoveVertical(-15);
        this.leftArm.slowMoveVertical(15);
        this.leftArm.slowMoveVertical(-15);
        this.leftArm.slowMoveVertical(15);
    }

    /**
     * Calling this method causes the robot to shake its head
     */
    public void shakeHead() {
        this.head.slowMoveHorizontal(20);
        this.head.slowMoveHorizontal(-40);
        this.head.slowMoveHorizontal(20);
    }
    
    /**
     * Give robot some colors
     */
    public void makeColorful()
    {
        this.head.changeColor("blue");
        this.body.changeColor("red");
        this.leftArm.changeColor("magenta");
        this.rightArm.changeColor("magenta");
        this.feet.changeColor("green");
    }

    /**
     * Move robot vertical by given distance
     * @param distance 
     */
    public void moveVertical(int distance)
    {
        //move each part by the specified distance
        this.head.moveVertical(distance);
        this.leftArm.moveVertical(distance);
        this.rightArm.moveVertical(distance);
        this.body.moveVertical(distance);
        this.feet.moveVertical(distance);
        
        //update its y coordinate
        this.yCoord += distance;
    }

    /**
     * Move robot horizontal by given distance
     * @param distance 
     */
    public void moveHorizontal(int distance)
    {
        //move each part by the specified distance
        this.head.moveHorizontal(distance);
        this.leftArm.moveHorizontal(distance);
        this.rightArm.moveHorizontal(distance);
        this.body.moveHorizontal(distance);
        this.feet.moveHorizontal(distance);

        //update its x coordinate
        this.xCoord += distance;
    }

    /**
     * Move robot to the specified location
     * @param x The x coordinate of given location
     * @param y The y coordinate of given location
     */
    public void moveTo(int x, int y)
    {
        this.moveHorizontal(x - this.xCoord);
        this.moveVertical(y - this.yCoord);
    }
}

