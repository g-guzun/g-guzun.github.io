/**
 * A temperature class.
 * 
 * @author David
 * @version 04/19/2015
 */
public class Temperature
{    
	//constants
    public static final int BOILING = 100;
    public static final int FREEZING = 0;

    //static methods
    /**
     * @return the converted temperature from Celsius to Fahrenheit
     */
    public static double celsiusToFahrenheit(double degrees)
    {
        return 9.0/5.0 * degrees + 32;
    }
    
    /**
     * @return the converted temperature from Fahrenheit to Celsius
     */
    public static double fahrenheitToCelsius(double degrees)
    {
        return 5.0/9.0 * (degrees - 32);
    }    
    
    
    //fields
    private double degreesInCelsius;
    
    /**
     * Creates a Temperature in degrees celcius
     * @param initTemp initial temperature
     */
    public Temperature(double initTemp)
    {
        degreesInCelsius = initTemp;
    }
    
    /**
     * @return current object's degrees in Celsius
     */
    public double getDegrees()
    {
        return degreesInCelsius;
    }

    /**
     * Setter for temperature
     * @param newDegrees a given degrees Celsius
     */
    public void setDegrees(double newDegrees)
    {
        degreesInCelsius = newDegrees;
    }

}
