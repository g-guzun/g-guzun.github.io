import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner inputSource = new Scanner(System.in);
        String yesno;   //holds user's response on whether to convert another
        
        System.out.println("Welcome to Temperature Program!");
        do {
            //prompt the user for a temperature
            System.out.print("\nEnter a degree in celsius: ");

            //get a temperature reading and convert it!
            double userTemp = Double.parseDouble(inputSource.nextLine());
            System.out.println(userTemp + " degrees (C) is " + Temperature.celsiusToFahrenheit(userTemp) + " degrees (F).");

            //does user want to convert another temperature?
            System.out.print("Convert another? (yes/no): ");
            yesno = inputSource.nextLine();
        } while (yesno.equalsIgnoreCase("yes"));

        
        //don't forget to close the Scanner object!
        inputSource.close();
    }
}
