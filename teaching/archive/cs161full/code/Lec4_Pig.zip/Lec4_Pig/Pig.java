/**
 * This Pig class is the best because...
 *
 * @author David
 * @version 1.1 Added method: sleep(int numSnores) 
 */

public class Pig
{
    //fields
    private double weight;
    private String noise;

    /**
     * Default constructor to create a Pig
     */
    public Pig()
    {
        noise = "Oink!";
        weight = 9.0;   //maybe the national average of Pigs is 9 lbs
    }
    
    /**
     * Creates a Pig with given weight
     * @param initWeight    The pig's initial weight
     */
    public Pig(double initWeight)
    {
        noise = "Oink!";
        weight = initWeight;
    }

    /**
     * Creates a Pig with given weight and noise
     * @param initNoise A custom noise the Pig says when it speaks
     * @param initWeight    The pig's initial weight
     */
    public Pig(String initNoise, double initWeight)
    {
        noise = initNoise;
        weight = initWeight;
    }

    /**
     * Gets the current weight of the pig
     * @return  weight of the pig
     */
    public double getWeight()
    {
        return weight;
    }

    /**
     * The Pig speaks
     */
    public void speak()
    {
        System.out.println(noise);
    }

    /**
     * The Pig sleeps
     */
    public void sleep()
    {
        System.out.println("Honk shooo");
    }

    /**
     * Make a given number of sleeping noises
     * @param numSnores Number of times to sleep
     */
    public void sleep(int numSnores)
    {
        while (numSnores > 0)
        {
            sleep();
            numSnores -= 1;
        }
    }

    /**
    There was something wrong with this version below. Can you figure out the bug?
 
    public void sleep(int numSnores)
    {
        int i = numSnores;
        while (i <= numSnores)
        {
            sleep();
            i -= 1;
        }
    }
    */

    /**
     * Gain weight and make eating noises.
     * Weight increases by factor of 10% of food weight
     * @param foodWeight 
     */
    public void eat(double foodWeight)
    {
        weight += 0.1 * foodWeight;
        System.out.println("Nom nom nom");
    }
}