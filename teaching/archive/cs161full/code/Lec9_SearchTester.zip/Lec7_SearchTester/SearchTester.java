import java.util.Random;

public class SearchTester
{
    public static void simulateAverageCase()
    {
        //simulation parameters
        int numSearchesToRun = 1000000;    //number of searches to run
        int numElementsInList = 2000;     //simulate linear serach over 10 elements
        
        //instantiate a Searcher object
        Searcher simulator = new Searcher(numElementsInList);
        
        //what is the average index of the found-key across searches?
        double indexSum = 0;
        Random randGen = new Random();
        for (int i = 0; i < numSearchesToRun; i += 1)
        {
            int key = randGen.nextInt(numElementsInList); //generate a random key
            int foundIndex = simulator.linearSearch(key); //find a random key
            indexSum += foundIndex;
        }
        System.out.println("List size (n) = " + numElementsInList + ", Number of Runs = " + numSearchesToRun + 
            ", Avg index of key found = " + indexSum/numSearchesToRun);
    }
}
