import java.util.Random;

public class Searcher
{
    private int[] list;

    /**
     * Constructs an array of the given size of random integers
     * @param size Length of the list
     */
    public Searcher(int size)
    {
        if (size <= 0)  //illegal size entered
        {
            size = 100;
        }
        list = new int[size];

        //fill the array with random numbers from 0 to size-1
        for (int i = 0; i < list.length; i += 1)
        {
            list[i] = i;
        }
        
        //shuffle the array so that numbers are in random places
        shuffle();
    }

    
    /**
     * This "shuffles" the elements around in the array
     * Like shuffling a deck of cards
     */
    private void shuffle()
    {
        Random rng = new Random();

        //loop through each element in the list
        int randIdx;
        for (int i = 0; i < list.length; i++)
        {
            //generate a random index from 0 to list.length-1
            randIdx = rng.nextInt(list.length);
            
            //swap current element with another element in the list
            int tmp = list[i];
            list[i] = list[randIdx];
            list[randIdx] = tmp;
        }
    }
    
    
    /**
     * Runs linear search for the key
     * @return index of first occurrence of key, or -1 if not found
     */
    public int linearSearch(int key)
    {
        // loop through the list from beginning to end
        for (int idx = 0; idx < list.length; idx++)
        {
            if (key == list[idx])
            {
                // found the key! return the index and stop!
                return idx;
            }
        }
        // didn't find the key! return -1
        return -1;
    }
    
    
    /**
     * Runs binary search for the key
     * @return index of first occurrence of key, or -1 if not found
     */
    public int binarySearch(int key)
    {
        int startIdx = 0, endIdx = list.length - 1;
        while (startIdx <= endIdx)
        {
            int midIdx = (startIdx+endIdx)/2; //find mid-point
            if (key == list[midIdx])
            {
               return midIdx;    // found the key! return the index and stop!
            }
            else if (key > list[midIdx])
            {
                startIdx = midIdx + 1;
            }
            else
            {
                endIdx = midIdx - 1;
            }
        }
       return -1;     // didn't find the key! return -1
    }
    
    /** @return The string representing the stored list */
    @Override
    public String toString()
    {
        String str = "";
        if (list.length > 0)
        {
            for (int i=0; i<list.length-1; i++)
            {
                str += list[i] + ", ";
            }
            return "[" + str + list[list.length-1] + "]";
        }
        return "[" + str + "]";
    }
}