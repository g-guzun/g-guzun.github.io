/**
 * Student class
 * @author David
 * @version 4/19/2020
 */
public class Student {
    /** static fields */
    public static final int MAX_NAME_LENGTH = 64;

    /** instance fields */
    private String name;
    private double GPA;
    private Rank classRank;

    public Student(String name) {
        if (name.length() <= Student.MAX_NAME_LENGTH) {
            this.name = name;
        }
        // assume new student is a freshman
        this.classRank = Rank.FR;
    }
    
    /**
     * Changes the student's name
     * @param name new name of student
     */
    public void changeName(String newName) {
        if (newName.length() <= Student.MAX_NAME_LENGTH) {
            this.name = newName;
        }
    }
    
    /**
     * @return the name of the student
     */
    public String getName() {
        return this.name;
    }
    
    /**
     * Changes the student's GPA
     * @param gpa new GPA
     */
    public void setGPA(double gpa) {
        if (gpa >= 0 && gpa <= 4.0) {
            this.GPA = gpa;
        }
    }
    
    /**
     * Changes the student's rank
     */
    public void changeRank(Rank newRank) {
        this.classRank = newRank;
    }
    
    /**
     * @return the student's class rank
     */
    public Rank getRank() {
        return this.classRank;
    }
}