/**
 * This Enum provides constants that signify 
 *  class ranks:
 * FR = freshman, SO = sophomore, JR = junior,
 * SR = senior, GRAD = graduate
 */
public enum Rank {
    FR, SO, JR, SR, GRAD
}