import java.util.ArrayList;

public class University
{
    private ArrayList<Student> allStudents;
    
    /**
     * Creates a new university
     */
    public University() {
        this.allStudents = new ArrayList<>();
    }

    /**
     * Adds a student
     */
    public void addStudent(Student newStudent) {
        this.allStudents.add(newStudent);
    }

    /**
     * Print an invitation to seniors
     */
    public void printInvitations() {
        //loop through the list of all students 
        for (int i = 0; i < this.allStudents.size(); i++) {

            //check if they're a senior
            if (this.allStudents.get(i).getRank() == Rank.SR) {
                System.out.println("Dear " + this.allStudents.get(i).getName() + ",");
                System.out.println("You're invited to Logger Bash!");                  
                System.out.println("Be there or be square.");
            }
        }
    }

}
