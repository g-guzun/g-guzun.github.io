
/**
 * Write a description of class PacManMain here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PacManMain
{
    public static void main(String[] args) {
        Circle body = new Circle();
        Circle eye = new Circle();
        Circle powerball = new Circle();
        Triangle mouth = new Triangle();
        body.makeVisible();
        eye.makeVisible();
        mouth.makeVisible();
        powerball.makeVisible();
        body.changeColor("yellow");
        body.changeSize(25);
        body.changeSize(75);
        body.moveDown();
        body.moveDown();
        body.moveUp();
        body.moveUp();
        body.moveUp();
        body.moveUp();
        eye.changeColor("black");
        eye.changeSize(5);
        eye.slowMoveHorizontal(58);
        mouth.changeSize(75,75);
        mouth.moveHorizontal(10);
        mouth.moveVertical(40);
        mouth.changeColor("white");
        powerball.changeColor("magenta");
        powerball.changeSize(20);
        powerball.slowMoveHorizontal(30);
        powerball.moveDown();
        powerball.moveDown();

    }
}
