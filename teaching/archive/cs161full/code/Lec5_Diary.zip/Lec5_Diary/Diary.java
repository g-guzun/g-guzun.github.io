import java.util.ArrayList;

/**
 * This class represents a simple diary.
 *
 * @author David
 * @version 3/27/2020
 */
public class Diary {
    private ArrayList<String> diary;
    
    public Diary() {
        this.diary = new ArrayList<>();
    }
    
    /**
     * Adds a new entry to the diary
     */
    public void addEntry(String entry) {
        this.diary.add(entry);
    }
    
    /**
     * @return the entry at the specified index, or null if index is invalid
     */
    public String getEntry(int index) {
        if (index >= 0 && index < this.diary.size()) {
            return this.diary.get(index);
        }
        return null;
    }
    
    /**
     * Prints all diary entries
     */
    public void printAll() {
        for (int i = 0; i < this.diary.size(); i++) {
            System.out.println(this.diary.get(i));
        }
    }
    
    /**
     * @return a list of entries containing the search string
     */
    public ArrayList<String> search(String str) {
        // a temporary list to hold the search results
        ArrayList<String> results = new ArrayList<>();
        for (int i = 0; i < this.diary.size(); i++) {
            String entry = this.diary.get(i);
            if (entry.indexOf(str) > -1) {
                // found an entry with the search string!
                results.add(entry);
            }
        }
        return results;
    }
    
    /**
     * @return the number of entries containing the search string
     */
    public int countEntriesContaining(String str) {
        return this.search(str).size();
    }

    /**
     * Deletes all entires containing the search string
     */
    public void removeEntriesContaining(String str) {
        for (int i = 0; i < this.diary.size(); i++) {
            String entry = this.diary.get(i);
            if (entry.indexOf(str) > -1) {
                this.diary.remove(i);
                i--;    // need to offset the index!
            }
        }
    }
}
