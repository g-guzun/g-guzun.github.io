/**
 * A class to store and run simple analysis over a set of 
 * measurements, or records.
 * 
 * @author David
 * @version 03/09/2015
 */
public class Bookkeeper
{
    private double[] records;   //points to an array of doubles
                                //currently pointing to null
    
    /**
     * Constructor
     * @param size Number of values we should store
     */
    public Bookkeeper(int numRecords)
    {
        //instantiate the array with numRecords double-elements, all holding 0
        if (numRecords <= 0)
        {
            System.out.println("Invalid size entered. Default to size 10.");
            numRecords = 10;
        }
        records = new double[numRecords];  
    }

    /**
     * Sets a value for a specified record index
     * 
     * @param  index The record's index. Range must be between 0 and records.length-1
     * @param  value The value for given record
     */
    public void setValue(int index, double value)
    {
        //only this range of values are legal
        if (index >= 0 && index <= records.length-1)
        {
            records[index] = value;
        }
        else
        {
            System.out.println("Error: Record " + index + " is out of range! Data not entered");
        }
    }
    
    /**
     * Gets a value at the specified index
     * @param   index The record's index. Range must be between 0 and records.length-1
     * @return  the value at the specified index, or NaN if index is invalid.
     */
    public double getValue(int index)
    {
        if (index >= 0 && index <= records.length-1)
        {
            return records[index];
        }
        //invalid index given! return not-a-number
        return Double.NaN;
    }

    /**
     * @return total value over all records
     */
    public double getTotal()
    {
        double total = 0;
        
        //loop through profits for each day
        for (int i = 0; i < records.length; i += 1)
        {
            total += records[i];
        }
        
        return total;
    }
    
    /**
     * @return average value over all records
     */
    public double getAverage()
    {
        return getTotal() / records.length;
    }

    /**
     * @return standard deviation
     */
    public double getStdev()
    {
        //std dev of one sample is undefined!
        if (records.length == 1)
        {
            //return Not-a-Number
            return Double.NaN;
        }
        else
        {
            //compute standard deviation
            double average = getAverage(); //get the mean
            double sumDist = 0; //stores the sum of squared distances from the mean
            for (int i = 0; i < records.length; i += 1)
            {
                sumDist += ((records[i] - average) * (records[i] - average));
            }
            return Math.sqrt(sumDist / (records.length-1));
        }
    }
    
    
    /**
     * @return standard deviation
     */
    public double getStdevSlow()
    {
        //std dev of one sample is undefined!
        if (records.length == 1)
        {
            //return Not-a-Number
            return Double.NaN;
        }
        else
        {
            //compute standard deviation
            double sumDist = 0; //stores the sum of squared distances from the mean
            for (int i = 0; i < records.length; i += 1)
            {
                sumDist += (records[i] - getAverage()) * (records[i] - getAverage());
            }
            return Math.sqrt(sumDist / (records.length-1));
        }
    }
    
    /**
     * @return the highest value recorded
     */
    public double getMax()
    {
        double max = records[0];
        
        //loop through records
        for (int i = 1; i < records.length; i += 1)
        {
            //we found a new highest value; update max
            if (max < records[i])
            {
                max = records[i];
            }
        }
        return max;
    }
    
    /**
     * @return the lowest value recorded
     */
    public double getMin()
    {
        double min = records[0];
        
        //loop through records
        for (int i = 1; i < records.length; i += 1)
        {
            //we found a new lowest value; update min
            if (min > records[i])
            {
                min = records[i];
            }
        }
        return min;
    }
    
    /**
     * Prints records line-by-line
     */
    public void showRecords()
    {
        for (int i = 0; i < records.length; i += 1)
        {
            System.out.println("record " + i + " = " + records[i]);
        }
    }
}
