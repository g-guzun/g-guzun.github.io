import java.util.Scanner;

/**
 * Collect statistics on user-input tweets
 * 
 * @author David Chiu
 * @version 11/3/2016
 */
public class Main
{
    public static void main(String[] args)
    {
        System.out.println("TweetProcessor! Initializing...");

        //TODO - create a scanner object
        Scanner keyboard = new Scanner(System.in);

        //TODO - create a TweetProcessor object
        TweetProcessor tp = new TweetProcessor();

        System.out.println("done!");

        String ans = "yes";
        while (ans.equals("yes"))
        {
            //here's a menu of options
            System.out.println("Select one of the following options: ");
            System.out.println("Enter 1 to reset the stats.");
            System.out.println("Enter 2 to input a tweet.");
            System.out.println("Enter 3 to print the collected stats.");

            //TODO - grab an option, parse the action, and do it.
            System.out.print("Option (1-3): ");
            int opt = Integer.parseInt(keyboard.nextLine());

            if (opt == 1)
            {
                tp.reset();
            }
            else if (opt == 2)
            {
                System.out.print("Enter a tweet: ");
                String tweet = keyboard.nextLine();
                tp.processTweet(tweet);
            }
            else if (opt == 3)
            {
                tp.printReport();
            }
            else
            {
                System.out.println("Error: option " + opt + " is invalid");
            }
            
            System.out.print("Continue? (yes or no): ");
            ans = keyboard.nextLine();
        }
        //TODO - later: get more than one tweet

        keyboard.close();
    }
}
