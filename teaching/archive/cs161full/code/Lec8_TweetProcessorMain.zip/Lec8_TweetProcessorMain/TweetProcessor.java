import java.util.StringTokenizer;

/**
 * Objects of this class can parse tweets and record statistics.
 * 
 * @author David Chiu
 * @version 03/05/2015
 */
public class TweetProcessor
{
    private int tweetCount;
    private int termCount;
    private int hashtagCount;
    private int mentionCount;

    /**
     * Constructor for objects of class TweetProcessor
     */
    public TweetProcessor()
    {
        reset();
    }

    /**
     * Resets all fields
     */
    public void reset()
    {
        tweetCount = 0;
        termCount = 0;
        hashtagCount = 0;
        mentionCount = 0;
    }

    /**
     * Prints statistics and report
     */
    public void printReport()
    {
        System.out.println("Number of Tweets: " + tweetCount);
        System.out.println("Number of Terms: " + termCount);
        System.out.println("Number of Hashtags: " + hashtagCount);
        System.out.println("Number of Mentions: " + mentionCount);
    }

    /**
     * @param a specified term from a tweet
     * @return whether given term is a #hashtag
     */
    public boolean isHashtag(String term)
    {
        //only check if term is at least 2 letters long
        if (term.length() > 1)
        {
            return term.startsWith("#");
        }
        return false;
    }

    /**
     * @param a specified term from a tweet
     * @return whether given term is a @mention
     */
    public boolean isMention(String term)
    {
        //only check if term is at least 2 letters long
        if (term.length() > 1)
        {
            return term.startsWith("@");
        }
        return false;
    }

    /**
     * Process a tweet
     * @param tweet
     */
    public void processTweet(String tweet)
    {
        if (tweet != null && !tweet.equals(""))
        {
            String term;
            StringTokenizer tokens = new StringTokenizer(tweet);

            //run through each term in the tweet
            while (tokens.hasMoreTokens())
            {
                term = tokens.nextToken(); //get a term

                if (isHashtag(term))
                {
                    hashtagCount++;
                }
                else if (isMention(term))
                {
                    mentionCount++;
                }

                //increment term count
                termCount++;
            }

            //increment tweet count
            tweetCount++;
        }
    }
}
