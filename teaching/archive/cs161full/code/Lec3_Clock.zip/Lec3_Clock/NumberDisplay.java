/**
 * This class models a two-digit number display.
 *
 * @author David
 * @version 8/4/17
 */
public class NumberDisplay
{
    private int value;
    private int limit;

    public NumberDisplay() {
        value = 0;
        limit = 0;
    }
    
    
    public NumberDisplay(int wraparound_limit) {
        value = 0;
        limit = wraparound_limit;
    }
    
    
    /**
     * @return the current value
     */
    public int getValue() {
        return value;
    }
    
    
    /**
     * Return a display value, i.e., if value is less than 10, it
     * will be padded with a leading zero.
     * 
     * @return a two-digit display value
     */
    public String toString() {
        if (value < 10) {
            return "0" + value;
        }
        return "" + value;
    }
    
    
    /**
     * Replace the current value with a new one. If the new value is
     * greater than the limit or less than 0, do nothing.
     * @param replacement_val the replacement value
     */
    public void setValue(int replacement_val) {
        if (replacement_val >= 0 && replacement_val < limit) {
            value = replacement_val;
        }
    }

    /**
     * Increments the value, or wraps around to 0 if limit has been reached.
     */
    public void tick() {
        value++;
        if (value == limit) {
            value = 0;
        }
    }
}
