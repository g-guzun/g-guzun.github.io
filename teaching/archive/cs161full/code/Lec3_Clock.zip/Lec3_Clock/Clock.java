
/**
 * This class implements a 24-hour digital clock. The range of the
 * clock goes from 00:00 to 23:59, before wrapping around to midnight.
 *
 * @author David
 * @version 8/4/17
 */
public class Clock
{
    private NumberDisplay hours;
    private NumberDisplay minutes;

    /**
     * Creates a new 24-hour format clock. Starts the time at 00:00.
     */
    public Clock()
    {
        hours = new NumberDisplay(24);
        minutes = new NumberDisplay(60);

        hours.setValue(0);
        minutes.setValue(0);
    }

    /**
     * Creates a new 24-hour format clock. Starts the time at the given hour and minutes.
     */
    public Clock(int start_hour, int start_minute)
    {
        hours = new NumberDisplay(24);
        minutes = new NumberDisplay(60);

        hours.setValue(start_hour);
        minutes.setValue(start_minute);
    }
    
    
    /**
     * This method gets called once a minute - it makes the clock display
     * go one minute forward.
     */
    public void timeTick()
    {
        minutes.tick();
        if (minutes.getValue() == 0) {
            //minute wrapped around! That means hour needs ticked too!
            hours.tick();
        }
    }

    /**
     * Sets the display to read the given time
     * @param hour 
     * @param minute
     */
    public void toString(int hour, int minute)
    {
        //Q: Do we worry about the given hours and minutes being in range?
        //A: Nope! NumberDisplay's setValue() ensures it (Thank you, abstraction!)
        hours.setValue(hour);
        minutes.setValue(minute);
    }
    
    /**
     * @return the time in HH:MM format
     */
    public String getTime() {
        //Q: Do we worry about padding single-digit times with a preceding 0?
        //A: Nope! NumberDisplay's toString() ensures it (Thank you, abstraction!)        
        return hours.toString() + ":" + minutes.toString();
    }
}
