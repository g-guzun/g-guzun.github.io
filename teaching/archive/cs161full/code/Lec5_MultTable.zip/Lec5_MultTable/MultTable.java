/**
 * A class that represents a multiplication table
 * @author David Chiu
 * @version 04/14/2015
 */

public class MultTable
{
    private int[][] table;

    /**
     * Creates and fills a multiplication table
     * @param initHeight    Height of Table
     * @param initWidth     Width of table
     */
    public MultTable(int initHeight, int initWidth)
    {
        table = new int[initHeight][initWidth];
        fillTable();
    }

    /**
     * Fills the multiplication table
     */
    private void fillTable()
    {
        for (int i = 0; i < table.length; i += 1)
           for (int j = 0; j < table[i].length; j += 1)
               table[i][j] = (i+1) * (j+1);
    }

    /**
     * Prints the multiplication table
     */
    public void printTable()
    {
        for (int i = 0; i < table.length; i += 1)
        {
            String rowOutput = "";
            for (int j = 0; j < table[i].length; j += 1)
                rowOutput += table[i][j] + "\t";
             System.out.println(rowOutput); //start new row
        }
    }
}