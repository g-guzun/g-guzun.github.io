
/**
 * This class contains the "main" method that, when called,
 * draws a pacman to the screen.
 *
 * @author David
 * @version 9/7/18
 */
public class PacManDrawer
{
    public static void main(String[] args) {
        // create the shapes I need for pacman
        Circle body = new Circle("yellow", 75);  // use our new overloaded constructor!
        Circle eye = new Circle("black", 5);     // use our new overloaded constructor!
        Triangle mouth = new Triangle();

        // boss around the objects to move them all into place!
        body.makeVisible();
        eye.makeVisible();
        mouth.makeVisible();
        body.moveDown();
        body.moveDown();
        body.moveUp();
        body.moveUp();
        body.moveUp();
        body.moveUp();
        eye.moveHorizontal(58);
        mouth.changeSize(75,75);
        mouth.moveHorizontal(10);
        mouth.moveVertical(40);
        mouth.changeColor("white");
    }
}
