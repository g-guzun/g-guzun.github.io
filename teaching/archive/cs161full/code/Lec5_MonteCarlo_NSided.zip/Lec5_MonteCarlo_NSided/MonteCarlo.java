
/**
 * This class allows users to test-roll certain Die an aribitrary number of times.
 * It is useful for finding loaded dice, since that requires a large number of rolls.
 * 
 * @author David
 * @version 10/09/2016
 */
public class MonteCarlo
{
    private Die myDie;                 //the die to test
    private int[] listOfCounts;     //stores an array of counts of face values.
        
    /**
     * Constructs a Monte Carlo simulator with a new default die.
     */
    public MonteCarlo()
    {
        this(new Die());        //call overloaded constructor with the default Die
    }

    /**
     * Constructs a Monte Carlo simulator with a given die.
     * @param initialDie    An initial die to test with.
     */
    public MonteCarlo(Die initialDie)
    {
        myDie = initialDie;
        listOfCounts = new int[myDie.getNumSides()];   //instantiate the array with NUM_SIDES elements
        reset();
    }
    
    /**
     * Clears all counts
     */
    public void reset()
    {
        for (int i = 0; i < myDie.getNumSides(); i++)
        {
            listOfCounts[i] = 0;
        }
    }

    /**
     * Clear all counts and pick up a new die
     * @param newDie    A given new die to use for testing
     */
    public void useDie(Die newDie)
    {
        myDie = newDie;

        //important: a new die could have a different number of sides
        //the counts array must change sizes too!
        listOfCounts = new int[myDie.getNumSides()];
    }

    /**
     * Rolls the current Die n times. Updates the counts for each roll.
     */
    public void roll(int n)
    {
        for (int i = 0; i < n; i++)
        {
            myDie.roll(); //roll the die
            
            //update the count at the proper place in the array!
            listOfCounts[myDie.getFaceValue()-1]++;
        }
    }
    
    
    /**
     * Prints a report on this die
     */
    public void printReport()
    {        
        System.out.println("==================");
        System.out.println("Simulation Results");
        System.out.println("==================\n");
        System.out.println("Rolled " + myDie.getNumRolls() + " times");

        for (int i = 0; i < myDie.getNumSides(); i++)
        {
            System.out.println((i+1) + ": " + listOfCounts[i] + " (" + (double) 100 * listOfCounts[i] / myDie.getNumRolls() + "%)");
        }
    }
}
