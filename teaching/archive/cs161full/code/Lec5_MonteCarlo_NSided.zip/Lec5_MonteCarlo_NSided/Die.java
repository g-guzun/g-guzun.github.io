import java.util.Random;

/**
 * This class simulates a single N-sided Die. The die may or may not be loaded to
 * favor a side.
 * 
 * @author David
 * @version 10/6/2016
 */
public class Die
{
    //constant (final) field. Can read it, can't write it (unless initializing)
    //value cannot change once number of sides is defined
    private final int NUM_SIDES; 
    
    //other fields
    private int faceValue;      //face value that's showing
    private boolean isLoaded;   //whether die is loaded
    private int loadedValue;    //value to favor if loaded
    private int numRolls;       //records the number of rolls
    private Random rng;         //random number generator
    
    /**
     * Creates a 6-sided die with a 20% probability of being loaded.
     */
    public Die()
    {
        //create a 6-sided Die with a 20% chance of being loaded
        //calls second constructor
        this(0.2);
    }

    /**
     * Creates a 6-sided die with a given probability for being loaded.
     * @param p a number between 0 and 1.
     */
    public Die(double p)
    {
        //create a six-sided Die
        //calls third constructor
        this(p, 6);
    }
    
    /**
     * Creates a die with a given probability for being loaded.
     * @param p A number between 0 and 1.
     * @param numSides The number of sides for this Die.
     */
    public Die(double p, int initSides)
    {
        //check for bad input of number of sides
        if (initSides <= 1)
        {
            NUM_SIDES = 6;
        }
        else
        {
            NUM_SIDES = initSides;
        }

        //ensure p is given within range
        if (p < 0)
        {
            p = 0;
        }
        else if (p > 1)
        {
            p = 1;
        }

        rng = new Random();
        if (rng.nextDouble() < p)
        {
            isLoaded = true;
            loadedValue = rng.nextInt(NUM_SIDES) + 1;
        }
        else
        {
            isLoaded = false;
        }
        
        //face value is a number between 1 and NUM_SIDES
        faceValue = rng.nextInt(NUM_SIDES) + 1;        
    }    
    
    
    /**
     * Rolls the die. If the die is loaded, then every 3 rolls will
     * turn up the favored (loaded) value.
     */
    public void roll()
    {
        numRolls++; //increase number of rolls

        // turns up a favored number every 3 rolls on a loaded die
        if (isLoaded && numRolls % 3 == 0)
        {
            faceValue = loadedValue;
        }
        else
        {
            //either not loaded or isn't the 3rd roll
            faceValue = rng.nextInt(NUM_SIDES) + 1;
        }
    }
    
    /**
     * @return the number of times this Die has been rolled
     */
    public int getNumRolls()
    {
        return numRolls;
    }
    
    /**
     * @return current value facing up
     */
    public int getFaceValue()
    {
        return faceValue;
    }

    /**
     * @return number of sides (faces) of this die
     */
    public int getNumSides()
    {
        return NUM_SIDES;
    }
}
