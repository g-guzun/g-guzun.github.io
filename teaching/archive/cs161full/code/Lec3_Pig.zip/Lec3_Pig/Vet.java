/**
 * Write a description of class Vet here.
 * 
 * @author David
 * @version 1.0
 */
public class Vet
{
    private Pig patient;

    /**
     * Default constructor.
     * Creates a Vet, who is not seeing any patients
     */
    public Vet()
    {
        patient = null;
    }

    /**
     * Creates a Vet, who is seeing the given patient
     */
    public Vet(Pig p)
    {
        patient = p;
    }

    /**
     * Sees a new patient
     * @param p A given Pig patient
     */
    public void evaluate(Pig p)
    {
        patient = p;
    }

    /**
     * Puts to patient to bed
     */
    public void putPatientToBed()
    {
        //is the vet actually seeing a patient?
        if (patient != null)
        {
            patient.sleep();
        }
    }

    /**
     * Feed the patient until desired weight is met! Does nothing
     * if desired weight is less than current weight.
     * 
     * @param desiredWeight The desired weight of the patient
     */
    public void feedUntil(double desiredWeight)
    {
        //is the vet actually seeing a patient?
        if (patient != null)
        {        

            double weightDifference = desiredWeight - patient.getWeight();

            //we only feed the Pig if desiredWeight > current weight
            if (weightDifference > 0)
            {
                //we know that a Pig retains only 10% of food weight
                double amountToFeed = weightDifference/0.1;
                System.out.println("Feeding the patient " + amountToFeed + " lbs of food");
                patient.eat(amountToFeed);
            }
            else
            {
                //pig already at or over the desired weight
                System.out.println("Not feeding patient - already at desired weight");
            }
        }
    }

    /**
     * Administer antibiotics
     * Under 10 lbs, then give 5.25 mg per lb
     * Between 10-54 lbs, then give 10.75 mg per lb
     * Above 55 lbs, then give 20.5 mg per lb
     */
    public void giveAntibiotics()
    {
        //is the vet actually seeing a patient?
        if (patient != null)
        {
            double weight = patient.getWeight();
            double dose = 0;

            if (weight < 10)
            {
                dose = 5.25 * weight;
            }
            else
            {
                if (weight < 54)
                {
                    dose = 10.75 * weight;
                }
                else
                {
                    dose = 20.5 * weight;
                }
            }
            System.out.println("Administered " + dose + " mg of antibiotics");
        }
    }
}