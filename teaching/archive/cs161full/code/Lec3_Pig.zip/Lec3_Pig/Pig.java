/**
 * This Pig class is the best because...
 * @author David
 * @version 1.0
 */

public class Pig
{
    //fields
    private double weight;
    private String noise;

    /**
     * Default constructor to create a Pig
     */
    public Pig()
    {
        noise = "Oink!";
        weight = 9.0;   //maybe the national average of Pigs is 9 lbs
    }
    
    /**
     * Creates a Pig with given weight
     * @param initWeight    The pig's initial weight
     */
    public Pig(double initWeight)
    {
        noise = "Oink!";
        weight = initWeight;
    }

    /**
     * Creates a Pig with given weight and noise
     * @param initNoise A custom noise the Pig says when it speaks
     * @param initWeight    The pig's initial weight
     */
    public Pig(String initNoise, double initWeight)
    {
        noise = initNoise;
        weight = initWeight;
    }
    
    /**
     * @return double weight of the pig
     */
    public double getWeight()
    {
        return weight;
    }

    /**
     * Make the Pig speak
     */
    public void speak()
    {
        System.out.println(noise);
    }

    /**
     * Make sleep noises
     */
    public void sleep()
    {
        System.out.println("Honk shooo");
    }

    /**
     * Gain weight and make eating noises
     * Weight increases by factor of 10% of food weight
     * @param foodWeight 
     */
    public void eat(double foodWeight)
    {
        weight += 0.1 * foodWeight;
        System.out.println("Nom nom nom");
    }

}