
/**
 * This class represents a bank that stores multiple account balances.
 *
 * @author David
 * @version 3/11
 */
public class Bank {
    private double[] accts;
    
    /**
     * Creates a bank
     * @param numAccts The maximum number of accounts
     */
    public Bank(int numAccts) {
        this.accts = new double[numAccts];
    }

    /**
     * Make a deposit
     * @param id The account number
     * @param amt The amount to deposit
     */
    public void deposit(int id, double amt) {
        if (id >= 0 && id < this.accts.length) {
            this.accts[id] += amt;
        }
    }
    
    /**
     * @return the average balance
     */
    public double getAvgBalance() {
        // sum up all the balances
        double total = 0;
        for (int id = 0; id < this.accts.length; id++) {
            total += this.accts[id];
        }
        
        // divide sum by number of accounts
        return total / this.accts.length;
    }
    
    /**
     * Prints a list of accounts with a balance lower than average
     */
    public void reportLowBalance() {
        double average = this.getAvgBalance(); // precompute avg and save
        for (int i = 0; i < this.accts.length; i++) {
            if (this.accts[i] < average) {
                System.out.println("Acct no: " + i + " has a low balance of: $" + this.accts[i]);
            }
        }
    }
}