/** 
 * Improved version of Student class, with information hiding and 
 * getter/setter methods to access fields.
 * 
 * @author David
 * @version 2
 */
public class Student
{
    //constants
    public static final int FRESHMAN = 1;
    public static final int SOPHOMORE = 2;
    public static final int JUNIOR = 3;
    public static final int SENIOR = 4;

    //class variables
    public static int numStudents;
    
    //fields
    private String name;    /** name of student */
    private int rank;       /** class rank */
    private double GPA;     /** gpa of student (should be within 0 and 4) */
    
    /**
     * Constructs a new Student with no name and no GPA and no gender
     */
    public Student()
    {
        Student.numStudents++;
    }

    /**
     * Sets the name of student
     * @param newName the given name of a student
     */
    public void setName(String newName)
    {
        name = newName;
    }

    /**
     * @return student's name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @return student's GPA
     */
    public String getGPA()
    {
        return name;
    }

    /**
     * Sets the student's GPA. Must be between 0 and 4
     * @param newGPA the given GPA of a student
     */
    public void setGPA(double newGPA)
    {
        //make sure given newGPA is within a legal range
        if (newGPA >= 0.0 && newGPA <= 4.0)
        {
            GPA = newGPA;
        }
        else
        {
            GPA = 0.0;
        }
    }
    
    /**
     * Sets the student's class rank (see constants)
     * @param newRank
     */
    public void setRank(int newRank)
    {
        rank = newRank;
    }

    /**
     * @return class rank (see constants)
     */
    public int getRank()
    {
        return rank;
    }
    
    //helper class to store some more structured info on a student
    private class Stats
    {
        private int height;
        private int weight;
        private String eyecolor;
        
        public Stats(int h, int w, String c)
        {
            height = h;
            weight = w;
            eyecolor = c;
        }
        public void setEyecolor(String c)
        { 
            eyecolor = c;
        }
        public String getEyecolor()
        {
            return eyecolor;
        }
        public void setWeight(int newWeight)
        { 
            weight = newWeight;
        }
        public int getWeight()
        {
            return weight;
        }
        public void setHeight(int newHeight)
        { 
            height = newHeight;
        }
        public int getHeight()
        {
            return height;
        }
    }

}