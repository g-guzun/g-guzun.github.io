import java.util.ArrayList;

/**
 * A simple University class that holds a list of Students
 * @author David
 * 
 */

public class University
{
    //fields
    private ArrayList<Student> allStudents;

    /**
     * Constructs a university object with an empty list of Students
     */
    public University()
    {
        //start with no students
        allStudents = new ArrayList<Student>();
    }
    
    /**
     * Adds the given student to the list
     * @param s A Student object
     */
    public void addStudent(Student s)
    {
        allStudents.add(s);
    }

    /**
     * Removes a student at the given index. No action if index is out-of-bounds
     * @param index Index at which the specified student is to be removed
     */
    public void removeStudent(int index)
    {
        //make sure index is within range
        if (index >= 0 && index < allStudents.size())
        {
            allStudents.remove(index);
        }
    }

    /**
     * Prints invitations for all seniors
     */
    public void printInvitations()
    {
        //loop through the list of all students 
        for (Student aStudent : allStudents)
        {
            //check if they're a senior
            if (aStudent.getRank() == Student.SENIOR)
            {
                System.out.println("Dear " + aStudent.getName() + ",");
                System.out.println("You're invited to Logger Bash!");                  
                System.out.println("Be there or be square.");
            }
        }
    }
}