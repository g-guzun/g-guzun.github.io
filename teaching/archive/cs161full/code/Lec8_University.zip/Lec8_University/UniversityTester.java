/**
 * Driver to run my script
 * 
 * @author David 
 * @version 1
 */
public class UniversityTester
{
    /**
     * Driver method
     */
    public static void main(String[] args)
    {
        University UPS = new University();
        Student david = new Student();
        david.setName("David");
        david.setGPA(3.0);
        david.setRank(Student.SENIOR);
        UPS.addStudent(david);

        Student hans = new Student();
        hans.setName("Hans");
        hans.setGPA(3.5);
        hans.setRank(Student.SENIOR);
        UPS.addStudent(hans);

        Student taylor = new Student();
        taylor.setName("Taylor");
        taylor.setGPA(3.8);
        taylor.setRank(Student.SENIOR);
        UPS.addStudent(taylor);

        UPS.printInvitations();
   }
}
