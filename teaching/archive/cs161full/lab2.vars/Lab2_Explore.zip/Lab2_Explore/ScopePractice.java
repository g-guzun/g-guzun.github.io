/**
 * The methods in this class use the assignment statement to change the values in the
 * fields (instance variables).  They'll be good practice as you get up to speed on
 * how assignment statements work.
 * 
 * @author David Chiu
 * @version 01/28/19
 */
public class ScopePractice {
    private int x;
    private int y;

    /**
     * This constructor calls the reset() method, which gives some initial values to the fields 
     * (instance variables).  You can call reset() again yourself at any time to get back to
     * the starting values.
     */
    public ScopePractice() {
        this.reset();
    }    

    /**
     * The reset() method sets x and y back to some initial values.
     */
    public void reset() {
        this.x = 50;
        this.y = 100;
    }

    public void test13() {
        // Note: I'm now declaring a and b to be "local" integer variables below:
        int a;
        int b;

        // Now I'm assigning them to new values
        a = this.x;
        b = this.y;

        //TODO (FOR YOU): add some code to print out the values of a and b
    }

    public void test14() {
        int a = 10;
        int b = 20;

        //TODO (FOR YOU): try to declare another local variable called `a' 

        //LATER (FOR YOU): try again, but this time declare `a' as a different data type (e.g., double)
        // Does it compile if 'a' is redeclared to hold a different type?
    }

    public void test15(int x, int y) {
        //TODO (FOR YOU): try declaring an local variable (any data type) named `x' or 'y'

    }    

    public void test16(int x, int y) {
        this.x = x;
        this.y = y;

        //TODO (FOR YOU): add some code to print out the value of x and y

        //ALSO (FOR YOU): add some code to print out the value of this.x and this.y
    }
}
