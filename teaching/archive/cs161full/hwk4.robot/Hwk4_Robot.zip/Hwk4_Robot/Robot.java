/**
 * Write a description of class Robot here.
 * 
 * @author (Your names)
 * @version (Today's date)
 */
public class Robot
{
    //fields
    
    //constructor
    
    //methods
    
}
