import java.util.Random;

/**
 * This class represents a single playing card. Playing cards have a suit,
 * which may be a club, spade, heart, or diamond, and a face value, which range from
 * 1 to 13.
 * 
 * @author (fill in)
 * @version (fill in)
 */
public class Card
{

    
    /**
     * Default constructor creates a random card
     */
    public Card()
    {
        //fill in code to generate random suit and face value
    }
    
     /**
     * Constructs a card with given suit and rank
     * @param suit  The given suit
     * @param value The given rank
     */
    public Card(Rank suit, int value)
    {
        //check if given suit and face values are both legal
        //if either is illegal, output an error and generate random card
        
        
    }
   
    //rest of the methods go here
    
}