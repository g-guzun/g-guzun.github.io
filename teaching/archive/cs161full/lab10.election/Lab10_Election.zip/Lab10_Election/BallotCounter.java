import java.util.*;
import java.io.*;

/**
 * Election class for Lab.
 *
 * @author David
 * @version 4/15/2020
 */
public class BallotCounter {
    private String candidateFile;               // candidate file name
    private String ballotFile;                  // ballot filename
    private HashMap<String, Integer> voteMap;   // map containing true results
   
    /**
     * Starts a new election. This method prompts users for the names
     * of files related to the election.
     */
    public BallotCounter() {
        // instantiate empty structures
        this.voteMap = new HashMap<>();
        
        // get file names from user
        Scanner keyboard = new Scanner(System.in);
        
        // get candidate file name
        System.out.print("Enter the name of candidate list: ");
        this.candidateFile = keyboard.nextLine();

        System.out.print("Enter the name of the ballot file: ");
        this.ballotFile = keyboard.nextLine();
    }
    
    /**
     * Reads files and computes the results in the map.
     */
    public void runElection() throws FileNotFoundException {
        // TODO: open candidate file. Initialize the map with candidates
        
        // TODO: open ballot file. Count the ballots and update map!
    }
    
    /**
     * Determines the winners
     * @return a list of winners from the election 
     * @pre Precondition: runElection() must be run before this method
     */
    public ArrayList<String> winners() {
        // create an ArrayList to return
        ArrayList<String> winners = new ArrayList<>();
        
        // TODO: First, determine the most votes. Loop through candidates' vote counts

        // TODO: Now find all the candidates who have the max vote count, add them
        // to the winners list!
        
        return winners;
    }

    /**
     * Saves the results to file.
     * @param filename file to write into
     * @pre Precondition: runElection() must be run before this method
     */
    public void saveResults(String filename) throws FileNotFoundException {
        PrintWriter out = new PrintWriter(new File(filename));
        
        // TODO write to file
        
        out.close();
    }
}