import java.util.Random;

/**
 * Write a description of class Combination here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class Combination
{
    
    /**
     * Constructor
     * @param initLength length of the combination
     * @param initMax maximum value of each number in the combination
     */
    public Combination(int initLength, int initMax)
    {

    }

    //more methods...
    
    /**
     * @return a string representation of the combination
     */
    public String toString()
    {
        //fill me in
        String str = "...";
        return str;
    }
}