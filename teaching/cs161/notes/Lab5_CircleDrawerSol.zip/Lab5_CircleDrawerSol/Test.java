public class Test
{
    public static void main(String[] args)
    {
        Circle c1 = new Circle();
        Circle c2 = new Circle(90);
        Circle c3 = new Circle(100);
        
        c2.changeColor("green");
        c3.changeColor("red");
        
        CircleDrawer d = new CircleDrawer(c1, c2);
        d.drawCircles();
        d.addCircle(c3);
        
        c1 = null;
        //c1.makeVisible();
    }
}
