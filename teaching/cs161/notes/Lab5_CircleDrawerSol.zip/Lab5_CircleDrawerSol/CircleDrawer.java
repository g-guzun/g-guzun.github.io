/**
 * CircleDrawer instances "remember" a pair of circles, and can make them
 * both visible or invisible.  More precisely, an instance of CircleDrawer
 * contains REFERENCES to two Circle objects.  These references are stored
 * in the instance variables named first and second.
 * 
 * @author David Chiu & Brad Richards
 * @version 9/2009
 */
public class CircleDrawer
{
    private Circle first;       // Reference to my most favorite circle
    private Circle second;      // Reference to my second most favorite circle

    /**
     * Default constructor sets both circle references to null.
     */
    public CircleDrawer() {
         this.first = null;
         this.second = null;
    }    
        
    /**
     * Takes two circle instances, uno and dos, and stores them in
     * the fields for later reference.
     * 
     * @param uno A reference to the first circle to be managed.
     * @param dos A reference to the second circle to be managed.
     */
    public CircleDrawer(Circle uno, Circle dos) {
         this.first = uno;
         this.second = dos;
    }
    
    public void drawLarger() {
        this.first.makeInvisible();
        this.second.makeInvisible();
        if (!(this.first.getDiameter() < this.second.getDiameter())) {
            first.makeVisible();
        }
        else if (!(this.first.getDiameter() > this.second.getDiameter())) {
            this.second.makeVisible();
        }
    }
    
    public void replaceSmallest(Circle c) {
        if (this.first == null) {
            this.first = c;
        }
        else if (this.second == null) {
            this.second = c;
        }
        else {  // they both point to an existing circle
            if (this.first.getDiameter() < this.second.getDiameter()) {
                this.first = this.second;
                this.second = c;
            }
            else {  // first >= second
                this.second = c;
            }
        }        
    }
    
    /**
     * Makes both of my favorite circles visible
     */
    public void drawCircles()
    {
        if (this.first != null && this.second != null)
        {
            if (this.first.getDiameter()/2.0 > 20 && this.first.getDiameter()/2.0 < 50) {            
                this.first.makeVisible();
            }

            if (this.second.getDiameter()/2.0 > 20 && this.second.getDiameter()/2.0 < 50) {            
                this.second.makeVisible();
            }
        }
    }
    
    /**
     * Makes both of my favorite circles invisible
     */
    public void eraseCircles()
    {
        if (this.first != null && this.second != null)
        {
            this.first.makeInvisible();
            this.second.makeInvisible();
        }
    }
    
    /**
     * Add a new circle to the group.  Make room by throwing away "first" and 
     * promoting "second" to first place.  Then add the new circle as "second".
     * (Order is important -- have to make first invisible before "losing" the
     * reference to it, and have to do the assignments in the right order.)
     * 
     * @param latest the newest Circle to be managed
     */
    public void addCircle(Circle latest) {
        this.first.makeInvisible();  // Eliminating the first
        this.first = this.second;         // Look inside box labelled "second", copy its arrow to "first"
        this.second = latest;        // Point to the same circle that latest does
        this.drawCircles();          // Make sure both new circles are visible now
    }
    
    
    /**
     * Draws both circles if they are equal in content.
     */
    public void drawWhenEquals() {
        if (this.first != null && this.second != null) {
            if (this.first.equals(this.second)) {
                this.drawCircles();
            }
            else {
                this.eraseCircles();
            }
        }
    }
}

