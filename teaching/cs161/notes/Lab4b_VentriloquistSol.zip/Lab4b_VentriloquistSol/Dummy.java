/**
 * Dummy class
 * 
 * @author David Chiu
 * @version 02/17/2015
 */
public class Dummy
{
    private String name;
    private String specialAction;

    /**
     * Default constructor that creates an "empty" Dummy
     */
    public Dummy()
    {
        name = "";
        specialAction = "";
    }
    
    /**
     * Constructor for objects of class Dummy
     * @param dummyName Given name for Dummy
     * @param dummyAction Given special action
     */
    public Dummy(String dummyName, String dummyAction)
    {
        name = dummyName;
        specialAction = dummyAction;
    }
    
    /**
     * @return Name of the Dummy
     */
    public String getName()
    {
        return name;
    }

    /**
     * Speaks a line
     * @param line A line for the Dummy to say
     */
    public void speak(String line)
    {
        System.out.println(name + " says, '" + line + "'");
    }

    /**
     * Setter for name
     * @param newName A given name for the Dummy
     */
    public void setName(String newName)
    {
        name = newName;
    }

    /**
     * Performs special action
     */
    public void doSpecialAction()
    {
        System.out.println(name + " " + specialAction);
    }
}
