/**
 * Write a description of class Ventriloquist here.
 * 
 * @author David Chiu
 * @version 02/17/2015
 */
public class Ventriloquist
{
    private String name;
    private Dummy puppet;

    /**
     * Constructor for objects of class Ventriloquist
     * @param venName A given name for the Ventriloquist
     */
    public Ventriloquist(String venName)
    {
        name = venName;
    }

    /**
     * Setter for ventriloquist's name
     * @param venName A given name for the Ventriloquist
     */
    public void setName(String newName)
    {
        name = newName;
    }
    
    /**
     * Getter for ventriloquist's name
     * @return name of the ventriloquist
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Picks up a Dummy
     * @param newDummy A given Dummy object
     */
    public void pickUpDummy(Dummy aPuppet)
    {
        puppet = aPuppet;
        System.out.println(name + " picks up " + puppet.getName());
    }

    /**
     * Makes the ventriloquist speak
     * @param line A line to say
     */
    public void speak(String line)
    {
        System.out.println(name + " says '" + line + "'");
    }

    /**
     * Makes the Dummy speak
     * @param line A line to have the Dummy say
     */
    public void makeDummySpeak(String line)
    {
        puppet.speak(line);
    }

    /**
     * Uses the Dummy's special action
     */
    public void useSpecialAction()
    {
        puppet.doSpecialAction();
    }
    
}
