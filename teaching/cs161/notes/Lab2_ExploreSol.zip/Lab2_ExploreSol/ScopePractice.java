/**
 * The methods in this class use the assignment statement to change the values in the
 * fields (instance variables).  They'll be good practice as you get up to speed on
 * how assignment statements work.
 * 
 * @author David Chiu
 * @version 9/7/17
 */
public class ScopePractice
{
    private int x;
    private int y;

    /**
     * This constructor calls the reset() method, which gives some initial values to the fields 
     * (instance variables).  You can call reset() again yourself at any time to get back to
     * the starting values.
     */
    public ScopePractice()
    {
       reset();
    }    
    
    /**
     * The reset() method sets x and y back to some initial values.
     */
    public void reset()
    {
       x = 50;
       y = 100;
    }
    
    public void test9()
    {
        x = x + 1;
        y = y + 2;
        
        System.out.println("x = " + x);   
        System.out.println("y = " + y);   
    }

    public void test10()
    {
        // Declare a and b as "local" variables
        int a;
        int b;
        
        a = x;
        b = y;
        
        //TODO: add some code to print out the values of a and b
        System.out.println("a = " + a);   
        System.out.println("b = " + b);   
    }

    public void test11()
    {
        // Declare `a' and `b' as "local" int variables
        int a = 10;
        int b = 20;
        
        //TODO: try to declare another local variable called `a' 
        //Solution: Can't be done! `a' already declared in this scope!

        //LATER: try again, but this time declare `a' as a different data type (e.g., double)
        //Solution: Can't be done! (Different data type doesn't matter!)
    }

    public void test12()
    {
        // Declare local variables called `x' and `y', 
        // which are names of your fields!
        int x = 10;
        int y = 20;
        
        //TODO: add some code to print out the value of x and y
        System.out.println("x = " + x);   
        System.out.println("y = " + y);   
    }

    public void test13()
    {
        int x = 500;
        int y = 1000;
        
        x = this.x;
        y = this.y;
        
        //TODO: add some code to print out the value of x and y
        System.out.println("x = " + x);   
        System.out.println("y = " + y);
        
        //ALSO: add some code to print out the value of this.x and this.y
        System.out.println("this.x = " + this.x);   
        System.out.println("this.y = " + this.y);
    }

    public void test14(int x, int y)
    {
        //TODO: try declaring an local int variable named `x'
        //Solution: Can't be done! This suggests that input parameters have the same scope as local variables!
    }    
    
    public void test15(int x, int y)
    {
        this.x = x;
        this.y = y;
        
        //TODO: add some code to print out the value of x and y
        System.out.println("x = " + x);   
        System.out.println("y = " + y);
        
        //ALSO: add some code to print out the value of this.x and this.y
        System.out.println("this.x = " + this.x);   
        System.out.println("this.y = " + this.y);   
    }
}
