/**
 * The methods in this class use the assignment statement to change the values in the
 * fields (instance variables).  They'll be good practice as you get up to speed on
 * how assignment statements work.
 * 
 * @author Brad Richards
 * @version 2017.01.26
 */
public class AsmtStmtPractice
{
    private int x;
    private int y;
    private int z;

    /**
     * This constructor calls the reset() method, which gives some initial values to the fields 
     * (instance variables).  You can call reset() again yourself at any time to get back to
     * the starting values.
     */
    public AsmtStmtPractice()
    {
       reset();
    }    
    
    /**
     * The reset() method sets x, y, and z back to some initial values.
     */
    public void reset()
    {
       x = 10;
       y = 20;
       z = 30;
    }
    
    
    
    
    /**
     * From here on down are methods you can use to practice your assignment statement
     * comprehension.  For each method, try to predict the values in x, y, and z at the
     * end of the assignment statements.  Then test your predictions by creating an
     * instance of the class, running the method, and using the object inspector to
     * peek at the values in x, y, and z.
     */

    public void test1()
    {
        x = 100;
        y = 5;
    }
    
    public void test2()
    {
        x = 100;
        x = 200;
    }
    
    public void test3()
    {
        x = z;
    }
    
    public void test4()
    {
        x = z;
        z = 100;
    }
    
    public void test5()
    {
        x = z;
        z = x;
    }
    
    public void test6()
    {
        y = z;
        x = y;
        z = 100;
    }
    
    public void test7()
    {
        z = 100;
        x = y;
        y = z;
        z = 5;
    }
    
    public void test8()
    {
        x = 2147483647;
        y = 1;
        z = x + y;
    }

}
