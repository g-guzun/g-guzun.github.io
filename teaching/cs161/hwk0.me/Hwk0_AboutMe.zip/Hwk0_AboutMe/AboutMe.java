
/**
 * Write a description of class AboutMe here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AboutMe
{
    public void printMyName() {
        // fill in your code for the printMyName method here
    }
}
