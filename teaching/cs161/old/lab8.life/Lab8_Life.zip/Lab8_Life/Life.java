import java.util.Random;

/**
 * A class that represents a (finite) board for Conway's Life.
 * 
 * @author YOUR_NAME_HERE
 */

public class Life
{
    //fields
    
    /**
     * A constructor for a new Life game
     * @param width the width of the board (in squares)
     * @param height the height of the board (in squares)
     */
    public Life(int width, int height)
    {
        //fill me in
    }

    /**
     * Updates the board for the next generation
     */
    public void nextGeneration()
    {
        //fill me in
    }
    
    /**
     * Returns whether or not a cell is alive.
     * @param x the x coord of the cell
     * @param y the y coord of the cell
     * @return whether the cell is alive or not
     */
    public boolean isAlive(int x, int y)
    {
        //fill me in
    }

    /**
     * Returns the number of living neighbors next to a cell.
     * @param x the x coord of the cell
     * @param y the y coord of the cell
     * @return the number of living neighbors next to the cell
     */
    public int countLivingNeighbors(int x, int y)
    {
        //fill me in
    }
    
    /**
     * Fills the board with random cells
     */
    public void fillRandom()
    {
        //fill me in
    }
    

}
