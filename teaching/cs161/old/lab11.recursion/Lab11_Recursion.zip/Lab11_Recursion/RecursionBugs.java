/**
 * These methods have bugs that you need to fix!
 * 
 * @author David 
 * @version 4/24/17
 */
public class RecursionBugs
{
    /**
     * This method prints every other number from n down to 0.
     */
    public static void skipPrint(int n) {
        if (n == 0) {
            System.out.println(0);
        }
        else {
            System.out.println(n);
            skipPrint(n-2);
        }
    }

    /**
     * This method performs linear search recursively. If the key is 
     * found at the head of the unexplored sublist, then you're done.
     * Otherwise, search for the key in the remaining unexplored sublist.
     * 
     * @param list  a list of integers
     * @param key   a search key
     * @param head  starting index of the unexplored sublist
     * @return position in which the key is found, or -1 if not found.
     */
    public static int linearSearch(int[] list, int key, int head) {
        if (key == list[head]) {
            return head;
        }
        if (key != list[head]) {
            return -1;
        }
        return linearSearch(list, key, head+1);
    }
}
