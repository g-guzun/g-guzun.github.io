import java.util.ArrayList;

/**
 * This class represents a single hand for the game, Black Jack.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hand
{
    private ArrayList<Card> hand;

    

}
