import java.io.*;
import java.util.*;
/**
 * This class contains the main method for running the pooled
 * sample tests.
 *
 * @author David
 * @version 9/3/2020
 */
public class PooledSampleTester
{
    private static String FILE = "pooling384_48_by_pool.txt";
    public static void main(String[] args) throws FileNotFoundException {
        /*
            "A", "I", "Q", "Y", "AG", "AO",  // sample 1 pool assignments
            "B", "J", "R", "Z", "AH", "AP"   // sample 2 pool assignments
         */
        System.out.println("Opening " + PooledSampleTester.FILE + "...");
        Detection d = new Detection(PooledSampleTester.FILE);        
        System.out.print("Testing pool integrity...");
        if (!d.checkPoolIntegrity()) {
            System.out.println("Failed!");
        }
        else {
            System.out.println("Passed!");
            
            // what are the positively identified pool labels? (from user)
            ArrayList<String> positiveLabels = inputPositivePoolIDs();

            // run the detection algorithm
            ArrayList<Integer> positiveSamples = d.detect(positiveLabels);
            if (positiveSamples.isEmpty()) {
                System.out.println("No samples tested positive.");
            }
            else {
                for (int sample : positiveSamples) {    
                    System.out.println("Sample " + sample + " tested positive.");                    
                }
            }
        }
    }

    /**
     * Helper method to get a list of positive pool labels.
     */
    private static ArrayList<String> inputPositivePoolIDs() {
        ArrayList<String> list = new ArrayList<>();
        Scanner keyboard = new Scanner(System.in);
        String in = "";
        do {
            System.out.print("Enter the ID of a pool testing positive (or 'stop'): ");
            in = keyboard.nextLine();
            list.add(in);
        }
        while (!in.equalsIgnoreCase("stop"));
        return list;
    }
}