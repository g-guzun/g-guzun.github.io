import java.util.ArrayList;

/**
 * This class represents a pool of test samples.
 *
 * @author David
 * @version 9/3/2020
 */
public class Pool
{
}
