import java.io.*;
import java.util.*;

/**
 * Write a description of class Detection here.
 *
 * @author David
 * @version 9/3/2020
 */
public class Detection
{
    public Detection(String filename) throws FileNotFoundException {
        // TODO
    }

    /**
     * @return a string containing all pools
     */
    public String toString() {
        // TODO
        return "";
    }
    
    /**
     * @return a list of Pools that contains the given sample
     */
    public ArrayList<Pool> getPoolsBySample(int sample) {
        // TODO
        return null;
    }

    /**
     * Ensures all pools have equal size
     * @return true if all pool sizes are the same, false otherwise
     */
    public boolean checkPoolIntegrity() {
        // TODO
        return false;
    }
    
    /**
     * Detects positive samples
     * @param positivePools a list containing IDs of pools testing positive
     * @return a list of samples testing positive
     */
    public ArrayList<Integer> detect(ArrayList<String> positivePoolLabels) {
        // TODO
        return null;
    }
}
