/**
 * Write a description of class Calculator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Calculator
{
	// instance variables (fields) - replace the example below with your own fields
	private int foo;

	/**
	 * Constructor for objects of class Calculator
	 */
	public Calculator()
	{
		// initialize instance variables
		foo = 100;
	}

	/**
	 * An example of a method - replace this comment with your own
	 * 
	 * @param  y   a sample parameter for sampleMethod
	 */
	public void sampleMethod(int y)
	{
		// put your code here
		foo = y;
	}
}
