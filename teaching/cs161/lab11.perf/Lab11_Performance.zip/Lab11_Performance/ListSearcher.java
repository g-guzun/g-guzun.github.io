import java.util.Random;
import java.util.Arrays;

/**
 * This class implements linear search, binary search, and findMedian
 * List generation methods are provided.
 * 
 * @author David Chiu and America Chambers
 * @version 11/02/2015
 */
public class ListSearcher {
    private int[] list;
    private Random rng;
    private long numComparisons;

    /**
     * Constructs an array of the given size of random integers
     * @param size Length of the list
     */
    public ListSearcher(int size) {
        numComparisons = 0;
        list = new int[size];
    }

    /**
     * Fills the internal array with unordered integers
     */
    public void generateUnorderedData() {
        // TODO
    }

    /**
     * This "shuffles" the elements around in the list
     */
    public void shuffle() {
        // TODO
    }

    /**
     * Fills the internal array with unordered integers
     */
    public void generateOrderedData() {
        // TODO
    }
    
    /**
     * @returns the number of comparisons
     */    
    public long getComparisons() {
        return numComparisons;
    }
    
    /**
     * Resets the number of comparisons to 0
     */
    public void resetComparisons() {
        numComparisons = 0;
    }

    /**
     * Runs linear search for the key
     * @return index of first occurrence of key, or -1 if not found
     */
    public int linearSearch(int key) {
        // loop through the list from beginning to end
        for (int idx = 0; idx < list.length; idx++) {
            numComparisons++;
            if (key == list[idx]) {
                return idx; // found the key! return the index and stop!
            }
        }
        // didn't find the key! return -1
        return -1;
    }

    /**
     * Runs binary search for the key
     * @return index of first occurrence of key, or -1 if not found
     */
    public int binarySearch(int key) {
        int startIdx = 0, endIdx = list.length-1;
        while (startIdx <= endIdx) {
            numComparisons++;
            int midIdx = (startIdx + endIdx) / 2; //find mid-point
            if (key == list[midIdx]) {
                return midIdx;    // found the key! return the index and stop!
            }
            else if (key > list[midIdx]) {
                startIdx = midIdx + 1;
            }
            else {
                endIdx = midIdx - 1;
            }
        }
        return -1;     // didn't find the key! return -1
    }

    /**
     * Finds the median value in a list (can be unsorted or sorted)
     * This method assumes there are NO duplicates in the list
     * @return the median value of the list
     */
    public int findMedian() {
        for(int i = 0; i < list.length; i++) {
            int lessThan = 0;   // counts how many numbers are less than list[i]
            int grtThan = 0;    // counts how many numbers are greater than list[i]

            for(int j = 0; j < list.length; j++) {
                numComparisons++;
                if(list[j] < list[i]) {
                    lessThan++;
                }
                else if(list[j] > list[i]) {
                    grtThan++;
                }
            }

            // If the list has odd length...
            if (list.length % 2 == 1 && lessThan == grtThan) {
                return list[i];
            }
            // If the list has even length...
            else if (list.length % 2 == 0 && lessThan == grtThan-1) {
                return list[i];
            }
        }
        //code should never reach here
        return -1;
    }

    /** 
     * @return The string representation of the list
     */
    public String toString() {
        return Arrays.toString(list);
    }
}