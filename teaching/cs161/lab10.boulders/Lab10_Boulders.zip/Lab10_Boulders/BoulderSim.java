import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;


public class BoulderSim
{
    // TODO - field(s)?    

    /**
     * Creates a collection of boulderCollection with the given file. The boulder data
     * is formatted as follows,
     * 
     *   diameter,xPosition,yPosition,xVelocity,yVelocity
     * 
     * @param filename the name of the file containing boulder information
     */
    public BoulderSim(String filename) throws FileNotFoundException
    {
        // TODO
    }

    /**
     * Updates every boulder's positions
     */
    public void animate(int numSteps)
    {
        // TODO 
    }
}
