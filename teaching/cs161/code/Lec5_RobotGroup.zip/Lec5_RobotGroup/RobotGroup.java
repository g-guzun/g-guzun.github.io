import java.util.Random;
import java.util.ArrayList;

/**
 * This class implements a group of bots (stored in an ArrayList).
 * 
 * @author David Chiu
 * @version 09/29/2016
 */
public class RobotGroup
{
    private ArrayList<Robot> listOfBots;
    
    /**
     * Creates an group of zero bots
     */
    public RobotGroup() {
        this.listOfBots = new ArrayList<>();
    }

    /**
     * Creates a new robot and adds it to the group
     */
    public void addRobot() {
        this.listOfBots.add(new Robot());
    }
    
    /**
     * Adds a given robot to the group
     * @param robot 
     */
    public void addRobot(Robot robot) {
        //make sure a null value wasn't given
        if (robot != null) {
            this.listOfBots.add(robot);
        }
    }

    /**
     * Discharge (removes) the robot at the specified index
     * @param index an index to the robot to remove
     * @return a reference to the discharged Robot
     */
    public Robot discharge(int index) {
        //ensure index is legal
        if (index >=0 && index < this.listOfBots.size()) {
            this.listOfBots.get(index).makeInvisible();
            return this.listOfBots.remove(index);
        }
        else {
            System.out.println("Error: index " + index + " is out of bounds");
            return null;
        }
    }

    /**
     * Discharges all Robots from the group
     */
    public void dischargeAll() {
        //remove them from the canvas first
        for (int i = 0; i < this.listOfBots.size(); i++) {
            this.listOfBots.get(i).makeInvisible();
        }

        //now clear the list
        this.listOfBots.clear();
    }
    
    /**
     * Shows all Robots
     */
    public void showAll() {
        for (int i = 0; i < this.listOfBots.size(); i++) {
            this.listOfBots.get(i).makeVisible();
        }        
    }
    
    /**
     * Hides all Robots
     */
    public void hideAll() {
        for (int i = 0; i < this.listOfBots.size(); i++) {
            this.listOfBots.get(i).makeInvisible();
        }
    }

    /**
     * Move all bots forward a given number of steps. Assume
     * each step moves the robot forward a given number of strides.
     *
     * @param steps number of steps to march
     */
    public void march(int steps) {
        if (steps > 0) {
            for (int countSteps = 0; countSteps < steps; countSteps++) {
                for (int i = 0; i < this.listOfBots.size(); i++) {
                    this.listOfBots.get(i).moveVertical(1);  //move the i_th Robot vertically by one unit
                }
            }
        }
    }
    
    /**
     * Move all bots to a random location on the 400 x 400 canvas
     */
    public void scatterAll() {
        Random rng = new Random();  //random number generator for each coordinate
        for (int i = 0; i < this.listOfBots.size(); i++) {
            this.listOfBots.get(i).moveTo(rng.nextInt(400), rng.nextInt(400));
        }
    }
    
    /**
     * @return the number of robots in the group
     */
    public int getSize() {
        return this.listOfBots.size();
    }
}
