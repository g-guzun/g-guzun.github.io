/**
 * A simple organism that can eat and think.
 *
 * @author David
 * @version 2/24/19
 */
public class Organism
{
    private String name;
    private Stomach stomach;
    private Brain brain;
    
    /**
     * A new organism has a given name, an empty stomach and a sleeping brain.
     */
    public Organism(String newName) {
        this.name = newName;
        this.stomach = new Stomach();
        this.brain = new Brain();
        this.brain.setAwake(false);  // go to sleep
    }
    
    /**
     * Puts the organism to sleep.
     */
    public void sleep() {
        if (this.brain.isAwake() == true) {
            System.out.println(this.name + " says: Zzz");
            this.brain.setAwake(false);
        }
    }

    /**
     * Wakes the organism up.
     */
    public void wakeUp() {
        if (this.brain.isAwake() == false) {
            System.out.println(this.name + " says: Yawn");
            this.brain.setAwake(true);
        }
    }

    /**
     * Eats the specified amount of food, and digests a random amount.
     * @param amount The amount of food to consume.
     */
    public void eat(int amount) {
        if (this.brain.isAwake() == true) {
            System.out.println(this.name + " says: Nom nom nom");
            this.stomach.ingest(amount);
            this.stomach.digest();
        }
    }

    /**
     * Prints the current thought.
     */
    public void speak() {
        if (this.brain.isAwake()) {
            System.out.println(this.name + " says: " + this.brain.getThought());
        }
    }
    
    /**
     * Remembers a thought in the brain.
     */
    public void remember(String newThought) {
        if (this.brain.isAwake()) {
            this.brain.setThought(newThought);
            System.out.println(this.name + " says: interesting...");
        }
    }
}
