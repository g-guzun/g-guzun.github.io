
public class Tester
{
    public static void main(String[] args) {
        Organism david = new Organism("David");
        david.wakeUp();
        david.eat(50);
        david.sleep();

        Organism adam = new Organism("Adam");
        adam.eat(50);  // should do nothing (still sleeping)
        adam.wakeUp();
        adam.wakeUp();  // should do nothing (already awake)
        adam.remember("I like computers.");
        adam.speak();
        adam.sleep();
    }
}
