/**
 * Write a description of class Brain here.
 *
 * @author David
 * @version 2/24/2019
 */
public class Brain
{
    private String thought;
    private boolean isAwake;

    /**
     * A default brain has no thought and is awake.
     */
    public Brain() {
        this.thought = "";
        this.isAwake = true;
    }

    /**
     * Inputs a thought, and stores it in the brain.
     * @param newThought A new thought to store in the brain
     */    
    public void setThought(String newThought) {
        this.thought = newThought;
    }

    /**
     * @return the current thought
     */
    public String getThought() {
        return this.thought;
    }

    /**
     * Sets the status of the brain to either awake or asleep.
     * @param newStatus the new awake status awake (true) or asleep (false)
     */
    public void setAwake(boolean newStatus) {
        this.isAwake = newStatus;
    }

    /**
     * @return whether or not the brain is awake    
     */
    public boolean isAwake() {
        return this.isAwake;
    }
}
