import java.util.Random;
public class Die {
    private int faceValue; // what's currently facing up?
    private Random rng;

    public Die() {
         this.rng = new Random();
         this.roll();
    }

    public void roll() {
        this.faceValue = this.rng.nextInt(6) + 1;   // [1,6]
    }
    
    /**
     * Rolls die n times
     * @param n Number of times to roll
     */
    public void rollRepeatedly(int n) {
        for (int timesRolled = 0; timesRolled < n; timesRolled++) {
            this.roll();
        }
    }
    
    /**
     * Rolls the die until a given number turns up
     * @param F the target facevalue
     * @return the number of rolls for F to show up
     */
    public int rollUntil(int F) {
        if (F < 1 || F > 6) {
            System.out.println("Error: out of range");
            return 0;
        }
        
        int timesRolled = 0;
        do {
            this.roll();
            timesRolled++;
        } while (this.faceValue != F);
        
        return timesRolled;
    }
}