/**
 * This class simulates a common ticket machine
 * @author David 
 * @version 2/13/2019
 */
public class TicketMachine
{
    /** fields */
    private int price;  // this is the cost per ticket
    private int balance; // money inserted so far
    private int total;  // money accumulated over time

    /**
     * Default constructor, zeroes out all fields
     */
    public TicketMachine() {
        this.price = 0;
        this.balance = 0;
        this.total = 0;
    }

    /**
     * Overloaded constructor that inputs the cost per ticket
     */
    public TicketMachine(int price) {
        this.price = price;
        this.balance = 0;
        this.total = 0;
    }

    /**
     * Allows user to input money into machine
     * @param amount The amount to insert
     * @return The current balance
     */
    public int insertMoney(int amount) {
        if (amount >= 0) {
            this.balance += amount;
        }
        else {
            System.out.println("Error invalid amount inserted!");
        }
        return this.balance;
    }

    public void printTicket() {
        if (balance >= this.price) {
            String ticket = "######################\n";
            ticket += "# The Puget Sound Line\n";
            ticket += "# Ticket\n";
            ticket += "# " + this.price + " dollars.\n";
            ticket += "######################";
            System.out.println(ticket);

            this.balance -= this.price;
            this.total += this.price;
        }
        else { //they must not have entered enough
            System.out.println("You still owe " + (this.price - this.balance) + " dollars!");
        }
    }    

}
