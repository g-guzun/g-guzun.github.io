import java.util.Random;

public class TurtleMob {
    private Turtle[] mob;

    /**
     * Constructor to create a TurtleMob with a specified number of
     * turtles.
     * @param N a specified number of pens
     */
    public TurtleMob(int N) {
        if (N < 0) {    //default behavior if N is given negative
            N = 3;
        }
        this.mob = new Turtle[N];

        // don't forget to loop through all array slots and put a Turtle inside!
        for (int i = 0; i < this.mob.length; i++) {
            this.mob[i] = new Turtle();
        }
    }

    /**
     * Lift all pens
     */
    public void allUp() {
        for (int i = 0; i < this.mob.length; i++) {
            this.mob[i].penUp();
        }        
    }

    /**
     * Lower all pens
     */
    public void allDown() {
        for (int i = 0; i < this.mob.length; i++) {
            this.mob[i].penDown();
        }
    }

    /**
     * Move all turtles forward by given distance
     * @param dist distance to go
     */
    public void allForward(int dist) {
        for (int i = 0; i < this.mob.length; i++) {
            this.mob[i].forward(dist);
        }
    }

    /**
     * Turn all turtles in the mob by a random amount
     */
    public void randomTurn() {
        Random rng = new Random();
        for (int i = 0; i < this.mob.length; i++) {
            this.mob[i].left(rng.nextInt(360));
        }
    }

    /**
     * Repeatedly turn and draw random amounts
     */
    public void goExplore() {
        Random rng = new Random();
        this.allDown();
        while (true) {
            this.randomTurn();
            this.allForward(rng.nextInt(51));
        }
    }

    /**
     * Get a subset of the turtles
     * @param start Index to start of the range
     * @param end   Index to end of the range
     * @return an array of Turtles indexed in the given range of indices
     *   or null if indices are invalid
     */
    public Turtle[] subset(int start, int end) {
        if (start <= end && (start > -1 && end < this.mob.length)) {
            Turtle[] subset = new Turtle[end-start+1];  // allocate array for subset of Turtles

            // copy over the turtles within the given range
            for (int i = start; i <= end; i++) {
                subset[i-start] = this.mob[i];
            }
            return subset;
        }
        return null;
    }

    /**
     * Appends another mob of Turtles to this one.
     * @param otherMob  Another mob of turtles
     */
    public void addMob(TurtleMob other) {
        if (other != null) {
            // create new array to hold all the turtles combined
            int bigSize = this.mob.length + other.mob.length;
            Turtle[] bigMob = new Turtle[bigSize];
            
            // bigMob is empty currently, so copy over all the current turtles
            for (int i = 0; i < this.mob.length; i++) {
                bigMob[i] = this.mob[i];
            }
            
            // now copy over turtles from other mob
            // but DON'T overwrite existing turtles
            for (int i = 0; i < other.mob.length; i++) {
                bigMob[this.mob.length + i] = other.mob[i];
            }
            
            // save bigMob
            this.mob = bigMob;
        }
    }
}