/**
 * This class represents a basic Robot. It can hide, appear, change colors,
 * and move about freely.
 * 
 * @author Joel Ross and David Chiu
 * @version 12/31/2014
 */
public class Robot
{
    //fields
    private Square body;
    private Circle head;
    private Circle leftArm;
    private Circle rightArm;
    private Triangle feet;
    private int xCoord;
    private int yCoord;

    /**
     * Constructor for objects of class Robot
     */
    public Robot()
    {
        head = new Circle();
        leftArm = new Circle();
        rightArm = new Circle();
        body = new Square();
        feet = new Triangle();

        head.moveTo(235, 100);
        body.changeSize(60);
        body.moveTo(220,130);
        leftArm.changeColor("magenta");
        leftArm.changeSize(15);
        leftArm.moveTo(285, 130);
        rightArm.changeColor("magenta");
        rightArm.changeSize(15);
        rightArm.moveTo(200, 130);
        feet.moveTo(250, 190);

        xCoord = 200;
        yCoord = 100;
    }

    /**
     * Changes robot's color to black
     */
    public void makeBlackAndWhite()
    {
        head.changeColor("black");
        leftArm.changeColor("black");
        rightArm.changeColor("black");
        body.changeColor("black");
        feet.changeColor("black");    
    }

    
    /**
     * Makes robot colorful
     */
    public void makeColorful()
    {
        head.changeColor("blue");
        leftArm.changeColor("magenta");
        rightArm.changeColor("magenta");
        body.changeColor("red");
        feet.changeColor("green");    
    }
    

    /**
     * Hide the Robot
     */
    public void makeInvisible()
    {
        head.makeInvisible();
        leftArm.makeInvisible();
        rightArm.makeInvisible();
        body.makeInvisible();
        feet.makeInvisible();    
    }        
 
    
    /**
     * Show the Robot
     */
    public void makeVisible()
    {
        head.makeVisible();
        leftArm.makeVisible();
        rightArm.makeVisible();
        body.makeVisible();
        feet.makeVisible();    
    }        

    
    /**
     * Move robot vertical by given distance
     * @param distance 
     */
    public void moveVertical(int distance)
    {
        head.moveVertical(distance);
        leftArm.moveVertical(distance);
        rightArm.moveVertical(distance);
        body.moveVertical(distance);
        feet.moveVertical(distance);
        yCoord += distance;
    }

    /**
     * Move robot horizontal by given distance
     * @param distance 
     */
    public void moveHorizontal(int distance)
    {
        head.moveHorizontal(distance);
        leftArm.moveHorizontal(distance);
        rightArm.moveHorizontal(distance);
        body.moveHorizontal(distance);
        feet.moveHorizontal(distance);
        xCoord += distance;
    }

    /**
     * Move robot to the specified location
     * @param x The x coordinate of given location
     * @param y The y coordinate of given location
     */
    public void moveTo(int x, int y)
    {
        moveHorizontal(x-xCoord);
        moveVertical(y-yCoord);
    }
}


