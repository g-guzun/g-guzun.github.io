import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * This class implements an army of bots (stored in an ArrayList).
 * 
 * @author David Chiu
 * @version 09/29/2016
 */
public class RobotArmy
{
    private ArrayList<Robot> listOfBots;
    
    /**
     * Creates an army of zero bots
     */
    public RobotArmy()
    {
        listOfBots = new ArrayList<Robot>();
    }

    /**
     * Creates a new robot and adds it to the army
     */
    public void addRobot()
    {
        listOfBots.add(new Robot());
    }
    
    /**
     * Adds a given robot to the army
     * @param robot 
     */
    public void addRobot(Robot robot)
    {
        //make sure a null value wasn't given
        if (robot != null)
        {
            listOfBots.add(robot);
        }
    }

    /**
     * Adds robots from a given file. The file format is as follows:
     * x_coord,y_coord,is_visible,is_colorful
     * 
     * @param filename A name for the file containing robot descriptions
     * @return The number of robots added
     */
    public int addRobots(String filename) throws FileNotFoundException
    {
        int count = 0;  //the number of robots added
        
        Scanner fileInput = new Scanner(new File(filename));
        while (fileInput.hasNext())
        {
            //grab an entire line from the file
            String entry = fileInput.nextLine();
            
            //extract tokens from each line entry (separated by commas)
            String[] tokens = entry.split(",");
            int xCoord = Integer.parseInt(tokens[0]);  //first token is x coordinate
            int yCoord = Integer.parseInt(tokens[1]);  //second token is y coordinate
            boolean isVisible = Boolean.parseBoolean(tokens[2]);  //third token is the Robot's visibility
            boolean isColorful = Boolean.parseBoolean(tokens[3]);  //fourth token is the Robot's color setting

            //create a new Robot with these attributes
            Robot newBot = new Robot();
            newBot.moveTo(xCoord, yCoord);
            if (isVisible)
            {
                newBot.makeVisible();
            }
            else
            {
                newBot.makeInvisible();
            }
            if (isColorful)
            {
                newBot.makeColorful();
            }
            else
            {
                newBot.makeBlackAndWhite();
            }

            //add the newly created Robot to the Army
            addRobot(newBot);
            count++;
        }
        fileInput.close();
        
        return count;
    }
    
    /**
     * Discharge (removes) the robot at the specified index
     * @param index an index to the robot to remove
     */
    public void discharge(int index)
    {
        //ensure index is legal
        if (index >=0 && index < listOfBots.size())
        {
            listOfBots.get(index).makeInvisible();
            listOfBots.remove(index);
        }
        else
        {
            System.out.println("Error: index " + index + " is out of bounds");
        }
    }
    
    /**
     * Discharges all Robots from the Army
     */
    public void dischargeAll()
    {
        listOfBots.clear();
    }
    
    /**
     * Shows all Robots
     */
    public void showAll()
    {
        for (int i = 0; i < listOfBots.size(); i++)
        {
            listOfBots.get(i).makeVisible();
        }        
    }
    
    /**
     * Hides all Robots
     */
    public void hideAll()
    {
        for (int i = 0; i < listOfBots.size(); i++)
        {
            listOfBots.get(i).makeInvisible();
        }
    }

    /**
     * Move all bots forward a given number of steps. Assume
     * each step moves the robot forward a given number of strides.
     *
     * @param steps number of steps to march
     * @param stride amount of units by which to move
     */
    public void march(int steps, int stride)
    {
        if (steps > 0)
        {
            for (int i = 0; i< listOfBots.size(); i++)
            {
                for (int countSteps = 0; countSteps < steps; countSteps++)
                {
                    listOfBots.get(i).moveVertical(stride);
                }
            }
        }
    }
    
    /**
     * Move all bots to a random location on the 400 x 400 canvas
     */
    public void scatterAll()
    {
        Random rng = new Random();  //random number generator for each coordinate
        for (int i = 0; i < listOfBots.size(); i++)
        {
            listOfBots.get(i).moveTo(rng.nextInt(400), rng.nextInt(400));
        }
    }
    
    /**
     * @return the number of robots in the army
     */
    public int getSize()
    {
        return listOfBots.size();
    }
}
