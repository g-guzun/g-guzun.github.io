import java.util.ArrayList;

/**
 * Objects of this class can parse tweets and record statistics.
 * 
 * @author David Chiu
 * @version 03/05/2015
 */
public class TweetParser
{
    private int tweetCount;
    private int termCount;
    private int hashtagCount;
    private int mentionCount;
    private int characterCount;
    private ArrayList<String> history;

    /**
     * Default constructor for objects of class TweetProcessor
     */
    public TweetParser()
    {
        history = new ArrayList<String>();
        reset();
    }

    /**
     * Resets all fields
     */
    public void reset()
    {
        tweetCount = 0;
        termCount = 0;
        hashtagCount = 0;
        mentionCount = 0;
        characterCount = 0;
        history.clear();
    }

    /**
     * Prints statistics and report
     */
    public void report()
    {
        System.out.println("Tweets: " + tweetCount);
        System.out.println("Terms: " + termCount);
        System.out.println("Characters: " + characterCount);
        System.out.println("Hashtags: " + hashtagCount);
        System.out.println("Mentions: " + mentionCount);

        //print hashtag history
        //if none has been found, print out a message stating so
        String history_str = "";
        if (!history.isEmpty()) {
            for (int i = 0; i < history.size(); i++)
            {
                history_str += history.get(i) + " ";
            }
        }
        else
        {
            history_str = "(no hashtags found)";
        }
        System.out.println("History ("+ history.size() +"): " + history_str);
    }

    /**
     * @param a specified term from a tweet
     * @return whether given term is a #hashtag
     */
    public boolean isHashtag(String term)
    {
        //only check if term is at least 2 letters long
        if (term.length() > 1)
        {
            return term.startsWith("#");
        }
        return false;
    }

    /**
     * @param a specified term from a tweet
     * @return whether given term is a @mention
     */
    public boolean isMention(String term)
    {
        //only check if term is at least 2 letters long
        if (term.length() > 1)
        {
            return term.startsWith("@");
        }
        return false;
    }
    
    /**
     * Process a tweet
     * @param tweet
     */
    public void processTweet(String tweet)
    {
        if (tweet != null && !tweet.equals(""))
        {
            String[] terms = tweet.split(" ");

            //run through each term in the tweet
            for (int i = 0; i < terms.length; i++)
            {
                if (isHashtag(terms[i]))
                {
                    hashtagCount++;

                    //add the hashtag to history if it's new
                    if (!history.contains(terms[i].toLowerCase())) {
                        history.add(terms[i].toLowerCase());   
                    }
                }
                else if (isMention(terms[i]))
                {
                    mentionCount++;
                }

                //increment term count
                termCount++;
            }

            //increment tweet count
            tweetCount++;
            
            //increment character count
            characterCount += tweet.length();
        }
    }
}
