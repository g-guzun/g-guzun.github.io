import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Write a description of class TweetsAnalyzer here.
 * 
 * @author David Chiu
 * @version 11/3/2016
 */
public class TweetsAnalyzer
{
   private TweetParser parser;
   
   /**
    * Constructs a new TweetsAnalyzer
    */
   public TweetsAnalyzer()
   {
       parser = new TweetParser();
   }
   
   /**
    * Processes the tweets from the file indicated by the given filename, which abides this format:
    * date [tab] handle [tab] tweet_content
    * 
    * @param filename a path to a tweet file
    */
   public void processTweetsFromFile(String filename) throws FileNotFoundException
   {
       Scanner file = new Scanner(new File(filename));
       while (file.hasNext())
       {
           //grab a tweet from the file (one per line)
           String tweet = file.nextLine();
           
           //the tweet content "payload" is the third token!
           String[] tokens = tweet.split("\t");
           parser.processTweet(tokens[2]);
       }
       file.close();
       
       //print out the report!
       parser.report();
   }
}
