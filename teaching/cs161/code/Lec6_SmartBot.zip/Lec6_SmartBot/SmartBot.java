import java.util.HashMap;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * A little smarter chatbot
 *
 * @author David
 * @version 10/24/2017
 */
public class SmartBot
{
    private Random rng;
    private ArrayList<String> responses;
    private HashMap<String,String> responseMap;

    /**
     * Creates a new chat bot
     */
    public SmartBot()
    {
        this.rng = new Random();
        this.responses = new ArrayList<>();
        this.responseMap = new HashMap<>();
        this.fillSnarkyResponses();
        this.fillResponseMap();
    }

    public void start()
    {
        this.printWelcome();

        Scanner keyboard = new Scanner(System.in);  // Used to get keyboard input
        String user_input;                          // Stores their response

        do {
            user_input = keyboard.nextLine();       // Get user input
            
            if (!user_input.equalsIgnoreCase("bye")) {
                this.printResponse(user_input); 
            }
        } while (!user_input.equalsIgnoreCase("bye"));
        this.printGoodbye();
    }
    
    /**
     * Fill a set of snarky responses
     */
    private void fillSnarkyResponses()
    {
        this.responses.add("Say, do you like cats?");
        this.responses.add("No one has ever complained about this before.");
        this.responses.add("You're not making any sense. Could you ask in a different way?");
        this.responses.add("I just Googled it. It doesn't know either.");
        this.responses.add("Calm down, I don't want to argue.");
    }
    
    /**
     * Fill the response map
     */
    private void fillResponseMap()
    {
        this.responseMap.put("crash", "It never crashes on our end. Must be something you're doing!");
        this.responseMap.put("crashes", "It never crashes on our end. Must be something you're doing!");
        this.responseMap.put("crashed", "It never crashes on our end. Must be something you're doing!");
        this.responseMap.put("crashing", "It never crashes on our end. Must be something you're doing!");
        this.responseMap.put("wifi", "Have you tried resetting your router?");
        this.responseMap.put("internet", "Have you tried resetting your router?");
        this.responseMap.put("network", "Have you tried resetting your router?");
        this.responseMap.put("slow", "I recommend installing more memory!");
        this.responseMap.put("sluggish", "I recommend installing more memory!");
        this.responseMap.put("heat", "One of your programs is probably stuck in an infinite loop. Terminate the offending program.");
        this.responseMap.put("scalding", "One of your programs is probably stuck in an infinite loop. Terminate the offending program.");
        this.responseMap.put("hot", "One of your programs is probably stuck in an infinite loop. Terminate the offending program.");
        this.responseMap.put("bug", "It's not a bug; it's a feature!");
        this.responseMap.put("bugs", "It's not a bug; it's a feature!");
        this.responseMap.put("buggy", "It's not a bug; it's a feature!");
        this.responseMap.put("thanks", "You're welcome. Type 'bye' if you're satisfied, or ask another question.");
    }
    
    /**
     * Prints a welcome message
     */
    private void printWelcome()
    {
        System.out.println("Tech support! How can I help?");
        System.out.println("Type 'bye' to end this session.");
    }

    /**
     * Prints good bye message
     */
    private void printGoodbye()
    {
        System.out.println("Glad I was able to help. Bye!");
    }
    
    /**
     * Print a random snarky response
     */
    private void printSnarkyResponse()
    {
        // Get a random response from the list
        String resp = this.responses.get(rng.nextInt(this.responses.size()));
        System.out.println(resp);
    }
    
    /**
     * Print a response, based on their question
     * @param question  a question from the user
     */
    private void printResponse(String question)
    {
        // Split their question into words
        String[] words = question.split(" ");
        
        // Loop through each word and check to see if it's a keyword!
        for (int i = 0; i < words.length; i++)
        {
            // Keyword is found in the map!
            if (this.responseMap.containsKey(words[i].toLowerCase()))
            {
                String resp = this.responseMap.get(words[i].toLowerCase()); // Get the response using the keyword!
                System.out.println(resp);
                return; //terminate the void method
            }
        }
        
        // Keyword is not in the map; just generate a snarky response!
        this.printSnarkyResponse();
    }
}