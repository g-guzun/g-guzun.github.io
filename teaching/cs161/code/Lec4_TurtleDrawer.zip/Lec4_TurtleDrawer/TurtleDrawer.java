public class TurtleDrawer
{
    private Turtle pen;

    /**
     * Constructor to create a new Turtle Graphics object
     */
    public TurtleDrawer()
    {
        pen = new Turtle();

        //other initialization code I'm withholding
        //(code omitted)
    }

    /**
     * Draw a square
     * @param sideLength The length of each side
     */
    public void drawSquare(int sideLength)
    {
        pen.penDown(); //get pen ready to draw

        //draw four edges
        for (int sidesDrawn = 0; sidesDrawn < 4; sidesDrawn++)
        {
            pen.forward(sideLength);
            pen.left(90);
        }
    }

    public void drawDashedLine(int numDashes, int dashLength)
    {
        //Loop needs to count up to given number of dashes
        for (int dashesToGo = numDashes; dashesToGo > 0; dashesToGo--)
        {
            //Pen down for odd iterations of loop
            if (dashesToGo % 2 == 1)
            {
                pen.penDown();
            }
            else
            {
                //Pen up for even iterations of loop
                pen.penUp();
            }
            
            pen.forward(dashLength);
        }
    }
}