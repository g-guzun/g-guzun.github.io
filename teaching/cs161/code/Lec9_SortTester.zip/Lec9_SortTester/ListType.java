
/**
 * Enumeration class ListType
 *
 * @author David
 * @version 5/1/2020
 */
public enum ListType {
    ORDERED,        
    UNORDERED, 
    MOSTLY_ORDERED_LOWITEM_LAST,
    MOSTLY_ORDERED_HIGHITEM_FIRST,
}
