public class Main {
    public static void main(String[] args) {
        int[] list = Sorter.getList(100000, ListType.UNORDERED);
        //int[] list = Sorter.getList(100000, ListType.MOSTLY_ORDERED_HIGHITEM_FIRST);
        //int[] list = Sorter.getList(100000, ListType.MOSTLY_ORDERED_LOWITEM_LAST);
        //int[] list = Sorter.getList(100000, ListType.ORDERED);

        Sorter.shakerSort(list);
        System.out.println("Sorted? " + Sorter.inAscendingOrder(list));
    }
}
