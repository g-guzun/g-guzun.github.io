import java.util.*;

/**
 * A class providing some sorting algorithms.
 * 
 * @author David
 * @version 04/4/2020
 */
public class Sorter
{
    /**
     * Constructs an array of the given size of random integers
     * @param size Length of the list
     */
    public static int[] getList(int size, ListType type) {
        Random rng = new Random();

        if (size <= 0) { //illegal size entered. Default to size 100 array {
            size = 100;
        }

        int[] list = new int[size];   //instanitate the array
        for (int i = 0; i < list.length; i++) {
            list[i] = i;
        }

        if (type == ListType.ORDERED) {
            return list;
        }
        else if (type == ListType.UNORDERED) {
            //shuffle the array so that numbers are shuffled in random places
            Sorter.shuffle(list);
        }
        else if (type == ListType.MOSTLY_ORDERED_LOWITEM_LAST) {
            list[list.length-1] = list[0];
        }
        else if (type == ListType.MOSTLY_ORDERED_HIGHITEM_FIRST) {
            list[0] = list[list.length-1];
        }
        return list;
    }

    /**
     * Uses selection sort to put the list in increasing order
     */
    public static void selectionSort(int[] list) {
        long startTime = System.nanoTime();

        //i is the index of the first element of the unsorted sublist
        for (int i = 0; i < list.length; i++) {
            int minIdx = i; //index of minimum element found so far in unsorted sublist
            for (int j = i+1; j < list.length; j++) {
                if (list[j] < list[minIdx]) {
                    //found a smaller element at list[j], so update minIdx to j
                    minIdx = j;
                }
            }
            //swap the two elements
            int temp = list[i];
            list[i] = list[minIdx];
            list[minIdx] = temp;
        }

        long endTime = System.nanoTime();
        System.out.println("Selection sort took: " + (endTime - startTime)/1000000.0 + "ms");
    }

    /**
     * Uses bubble sort to put the list in increasing order
     */
    public static void bubbleSort(int[] list) {
        long startTime = System.nanoTime();        

        boolean swapped = true; //lets us short-circuit the loop if no swaps were made
        for (int i = 0; swapped && i < list.length; i++) {
            swapped = false;
            for (int j = 1; j < list.length - i; j++) {
                if (list[j-1] > list[j]) {
                    //swap the two elements (bubble larger one up)
                    int temp = list[j-1];
                    list[j-1] = list[j];
                    list[j] = temp;

                    //indicate that a swap was made
                    swapped = true;
                }
            }
            //print out the contents of array after each pass
            //System.out.println(toString());
        }

        long endTime = System.nanoTime();
        System.out.println("Bubble sort took: " + (endTime - startTime)/1000000.0 + "ms");
    }

    /**
     * Uses shaker sort to put the list in increasing order
     */
    public static void shakerSort(int[] list) {
        long startTime = System.nanoTime();
        boolean swapped = true; //lets us short-circuit the loop if no swaps were made
        for (int i = 0; swapped && i < list.length/2; i++) {
            swapped = false;
            // Direction: -->
            for (int j = 1; j < list.length - i; j++) {
                if (list[j-1] > list[j]) {
                    //swap the two elements (bubble larger one up)
                    int temp = list[j-1];
                    list[j-1] = list[j];
                    list[j] = temp;

                    //indicate that a swap was made
                    swapped = true;
                }
            }
            // do we even have to go the other direction?
            if (swapped) {
                // Direction: <--
                for (int j = list.length - i - 1; j > i; j--) {
                    if (list[j-1] > list[j]) {
                        //swap the two elements (bubble smaller one down)
                        int temp = list[j-1];
                        list[j-1] = list[j];
                        list[j] = temp;
                    }
                }
            }
        }

        long endTime = System.nanoTime();
        System.out.println("Shaker sort took: " + (endTime - startTime)/1000000.0 + "ms");
    }

    /**
     * BogoSort!
     */
    public static void bogoSort(int[] list) {
        while (!Sorter.inAscendingOrder(list)) {
            Sorter.shuffle(list);
        }
    }

    /**
     * @return true if list is in ascending order, false otherwise
     */
    public static boolean inAscendingOrder(int[] list) {
        for (int i = 1; i < list.length; i++) {
            if (list[i-1] > list[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * This "shuffles" the elements around in the array
     * Like shuffling a deck of cards
     */
    public static int[] shuffle(int[] list) {
        Random rng = new Random();

        //loop through each element in the list
        int randIdx;
        for (int i = 0; i < list.length; i++) {
            //generate a random index from i to list.length-1
            randIdx = rng.nextInt(list.length-i) + i;

            //swap current element with another element in the list
            int tmp = list[i];
            list[i] = list[randIdx];
            list[randIdx] = tmp;
        }
        
        return list;
    }
}