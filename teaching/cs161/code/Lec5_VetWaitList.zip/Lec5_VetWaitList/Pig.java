/**
 * This Pig class is the best because...
 *
 * @author David
 * @version 1.1 Added method: sleep(int numSnores) 
 */

public class Pig
{
    //fields
    private double weight;
    private String noise;
    private String name;

    //Creates a Pig with given weight
    public Pig(String initName, double initWeight)
    {
        name = initName;
        noise = "Oink!";
        weight = initWeight;
    }

    /**
     * Creates a Pig with given weight and noise
     */
    public Pig(String initName, String initNoise, double initWeight)
    {
        name = initName;
        noise = initNoise;
        weight = initWeight;
    }

    /**
     * @return name of the Pig
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * @return double weight of the pig
     */
    public double getWeight()
    {
        return weight;
    }

    /**
     * Make the Pig speak
     */
    public void speak()
    {
        System.out.println(noise);
    }

    /**
     * Make sleep noises
     */
    public void sleep()
    {
        System.out.println("Honk shooo");
    }

    /**
     * Make a given number of sleeping noises
     * @param numSnores Number of times to sleep
     */
    public void sleep(int numSnores)
    {
        while (numSnores > 0)
        {
            sleep();
            numSnores -= 1;
        }
    }

   
    //There was something wrong with this version..
    /*
    public void sleep(int numSnores)
    {
        int i = numSnores;
        while (i <= numSnores)
        {
            sleep();
            i -= 1;
        }
    }
    */

    /**
     * Gain weight and make eating noises
     * Weight increases by factor of 10% of food weight
     * @param foodWeight 
     */
    public void eat(double foodWeight)
    {
        weight += 0.1 * foodWeight;
        System.out.println("Nom nom nom");
    }

}