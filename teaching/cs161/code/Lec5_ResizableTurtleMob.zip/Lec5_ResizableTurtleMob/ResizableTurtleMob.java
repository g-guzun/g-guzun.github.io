import java.util.Random;
import java.util.ArrayList;


public class ResizableTurtleMob {
    private ArrayList<Turtle> mob;

    /**
     * Constructor to create a TurtleMob with a specified number of
     * turtles.
     * @param N a specified number of pens
     */
    public ResizableTurtleMob() {
        this.mob = new ArrayList<>();
    }
    
    /**
     * Creates a new turtle and add to the end of the list.
     */
    public void addTurtle() {
        this.mob.add(new Turtle());
    }

    public void removeTurtle() {
        if (this.mob.size() > 0) {
            this.mob.remove(0);
        }
    }
    
    /**
     * Lift all pens
     */
    public void allUp() {
        for (int i = 0; i < this.mob.size(); i++) {
            this.mob.get(i).penUp();
        }
    }

    /**
     * Lower all pens
     */
    public void allDown() {
        for (int i = 0; i < this.mob.size(); i++) {
            this.mob.get(i).penDown();
        }
    }

    /**
     * Move all turtles forward by given distance
     * @param dist distance to go
     */
    public void allForward(int dist) {
        for (int i = 0; i < this.mob.size(); i++) {
            this.mob.get(i).forward(dist);
        }
    }

    /**
     * Turn all turtles in the mob by a random amount
     */
    public void randomTurn() {
        Random rng = new Random();
        for (int i = 0; i < this.mob.size(); i++) {
            this.mob.get(i).left(rng.nextInt(360));
        }
    }

    /**
     * Repeatedly turn and draw random amounts
     */
    public void goExplore() {
        Random rng = new Random();
        this.allDown();
        while (true) {
            this.randomTurn();
            this.allForward(rng.nextInt(51));
        }
    }
}