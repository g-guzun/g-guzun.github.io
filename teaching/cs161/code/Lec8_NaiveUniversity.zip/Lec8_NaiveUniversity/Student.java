/**
 * A very poorly designed Student class.
 * Note the fields are public
 * 
 * @author David
 * @version 1
 */
public class Student
{
    /** name of student */
    public String n;  
    /** gpa of student (should be within 0 and 4) */
    public double g;
    /** class rank */
    public String r;

    /**
     * Constructs a new Student with no name and no GPA
     */
    public Student()
    {
    }
    
}