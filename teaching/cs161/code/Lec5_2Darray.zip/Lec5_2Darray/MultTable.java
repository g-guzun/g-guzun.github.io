/**
 * A class that represents a multiplication table, just like we learned
 * in elementary school. Zeroes are ignored.
 * 
 * @author David
 * @version 04/14/2015
 */

public class MultTable
{
    private int[][] table;  //the multiplication table.

    /**
     * Creates and fills a multiplication table
     * @param initHeight    Height of Table
     * @param initWidth     Width of table
     */
    public MultTable(int initHeight, int initWidth)
    {
        table = new int[initHeight][initWidth];
        fillTable();
    }

    /**
     * A helper method that fills the multiplication table.
     * Note: this method is --private-- 
     * It can only be called internally. Objects from other classes cannot use it!
     */
    private void fillTable()
    {
        for (int i = 0; i < table.length; i++)
        {
           for (int j = 0; j < table[i].length; j++)
           {
               table[i][j] = (i+1) * (j+1);
           }
        }
    }

    /**
     * @return The String representation of the multiplication table
     */
    public String toString()
    {
        String str = "";
        for (int i = 0; i < table.length; i++)
        {
            for (int j = 0; j < table[i].length; j++)
            {
                str += table[i][j] + "\t";
            }
            str += "\n"; //start new row
        }
        return str;
    }
    
    /**
     * Prints the multiplication table
     */
    public void printTable()
    {
        System.out.println(toString());
    }
}