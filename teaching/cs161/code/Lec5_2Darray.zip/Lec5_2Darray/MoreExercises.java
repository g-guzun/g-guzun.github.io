import java.util.Random;

public class MoreExercises
{
    private int[][] A;

    /**
     * Constructor that populates a size-by-size 2D array
     * with random integers.
     * @param size  dimension of the aray
     */
    public MoreExercises(int size)
    {
        //ensure size is a legal value
        if (size <= 0)
        {
            size = 10;
        }

        //instantiate the array, and populate it with random numbers
        Random rng = new Random();
        A = new int[size][size];
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                A[i][j] = rng.nextInt();
            }
        }
    }

    /**
     * @return the number of even numbers in the 2D array
     */
    public int numEvens()
    {
        int count = 0;   //holds the number of even numbers found
        for (int i = 0; i < A.length; i++)
        {
            for (int j = 0; j < A[0].length; j++)
            {
                if (A[i][j] % 2 == 0)
                {
                    count++;
                }
            }
        }
        return count;
    }
    
    /**
     * @return the average of all elements stored in the 2D array
     */
    public double getAvg()
    {
        int numElements = 0; //why do we need this?
        int sum = 0;
        for (int i = 0; i < A.length; i++)
        {
            for (int j = 0; j < A[0].length; j++)
            {
                sum += A[i][j];
                numElements++;
            }
        }
        return (double) sum / numElements;
    }
    
    /**
     * @return the number of elements less than the average
     */
    public int lessThanAvg()
    {
        int count = 0;  //count of elements less than average
        double avg = getAvg();
        for (int i = 0; i < A.length; i++)
        {
            for (int j = 0; j < A[0].length; j++)
            {
                if (A[i][j] < avg)
                {
                    count++;
                }
            }
        }
        return count;
    }    
    
}
