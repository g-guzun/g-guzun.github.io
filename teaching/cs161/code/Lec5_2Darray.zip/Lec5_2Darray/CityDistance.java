
public class CityDistance
{
    public static final int NUM_CITIES = 4;
    public static final int CHICAGO = 0;
    public static final int BOSTON = 1;
    public static final int NYC = 2;
    public static final int ATLANTA = 3;
    
    private final double[][] distances = {
      {0, 983, 787, 714},
      {983, 0, 214, 1102},
      {787, 214, 0, 888},
      {714, 110, 2, 888, 0}
    };

    public double getDistance(int cityID1, int cityID2)
    {
        //ensure both IDs are valid
        if (cityID1 >= 0 && cityID1 < NUM_CITIES && cityID2 >= 0 && cityID2 < NUM_CITIES)
        {
            return distances[cityID1][cityID2];
        }
        
        //invalid ID obtained
        System.out.println("Error: invalid city ID");
        return -1;  //return something that would clearly indicate an erroneous distance.
    }

    /**
     * @return the nearest city's ID to the given city
     */
    public int getNearestCityID(int cityID)
    {
        if (cityID >= 0 && cityID < CityDistance.NUM_CITIES)
        {
            int nearestID = 0;
            for (int i = 0; i < CityDistance.NUM_CITIES; i++)
            {
                //skip itself (zero distance)
                if (nearestID != cityID)
                {
                    if (distances[cityID][nearestID] > distances[cityID][i])
                    {
                        nearestID = i;
                    }
                }
            }
            return nearestID;
        }
        
        //invalid ID obtained
        System.out.println("Error: invalid city ID given");
        return -1;
    }
}
