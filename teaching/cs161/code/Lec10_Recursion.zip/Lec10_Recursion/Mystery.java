
/**
 * Mysterious recursive methods
 * 
 * @author David
 * @version 12/1/2017
 */
public class Mystery
{
    
    /**
     * What does this method do?
     */
    public static String mystery0(String s, int n)
    {
        if (n < 0) {        // Base case
            System.out.println("n can't be negative");
            return "";
        }
        else if (n == 0) {  // Base case
            return "";
        }
        else if (n == 1) {  // Base case
            return s;
        }
        else {  // Recursive case
            return s + mystery0(s, n-1);
        }
    }
}
