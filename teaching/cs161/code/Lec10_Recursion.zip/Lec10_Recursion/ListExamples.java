import java.util.ArrayList;

public class ListExamples
{
    
    /**
     * Recursively adds all elements in the list
     * @param list an integer array
     * @param head the position of the current head element to add
     * @return sum of all elements in the list
     */
    public static int recursiveSum(int[] list, int head)
    {
        //base case (trivial)! Nothing left to add
        if (head >= list.length) {
            return 0;
        }
        //general case (be lazy)
        return list[head] + recursiveSum(list, head + 1);
    }
    
    /**
     * Recursively (linear) searches for the key in the list
     * @param list an integer array
     * @param key the search key
     * @param head the position of the current element to compare with key
     * @return true if key is found
     */
    public static boolean recSearch(int[] list, int key)
    {
        return recSearch_helper(list, key, 0);
    }
    
    private static boolean recSearch_helper(int[] list, int key, int head)
    {        
        //base case -- Nothing left to check, key can't be found
        if (head >= list.length)
        {
            return false;
        }

        //base case 2 -- found the key at the specified index of the list!
        else if (list[head] == key)
        {
            return true;
        }

        //general case
        head++;
        return recSearch_helper(list, key, head);
    }

    /**
     * Checks if given list is a palindrome (read the same forward and backward)
     */
    public static boolean isPalindrome(int[] list, int start, int end)
    {
        if (start > end) {
            return true;
        }
        return list[start] == list[end] && isPalindrome(list, start + 1, end - 1);
    }
}
