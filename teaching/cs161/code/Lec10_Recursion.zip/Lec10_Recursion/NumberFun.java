
/**
 * Fun with numbers
 * 
 * @author David
 * @version 12/1/17
 */
public class NumberFun
{
    /**
     * Finds the nth Fibonacci number (recursive)
     */
    public static long fib(int n)
    {
        if (n == 0) {
            // Base case -- the zeroth Fibonacci number is 0 (by definition)
            return 0;
        }
        else if (n == 1) {
            // Base case -- the first Fibonacci number is 1 (by definition)
            return 1;
        }
        // Recursive case -- the nth Fibonacci number is the sum of 
        // the two previous Fibonacci numbers
        return fib(n-2) + fib(n-1);
    }
    
    /**
     * Finds the nth Fibonacci number (iterative)
     */
    public static long itrFib(int n)
    {
        //first two fibonacci numbers are known
        if (n == 0) {
            return 0;
        }
        else if (n == 1) {
            return 1;
        }
        else
        {
            long fib_prev = 0, fib_now = 1;
            for (int i = 2; i <= n; i++)
            {
                long tmp = fib_now;
                fib_now = fib_prev + fib_now;
                fib_prev = tmp;
            }
            return fib_now;
        }
    }

    /**
     * Repeatedly prints out the ratio between two consecutive Fibonacci numbers.
     */
    public static void printRatio() {
        int n = 2;
        while (true) {
            System.out.println("n = " + n + ", phi ~= "  + ((double) fib(n)) / fib(n-1));
            n++;
        }
    }    
    
    /**
     * Determines recursively whether the given number is prime.
     * @return true if prime, false otherwise
     */
    public static boolean isPrime(int n) {
        return isPrime_helper(n, 2);
    }
    
    private static boolean isPrime_helper(int n, int divisor) {
        if (n < 2) {
            return false;
        }
        else if (n == divisor) {
            return true;
        }
        else {
            return (n % divisor != 0) && isPrime_helper(n, divisor+1);
        }
    }
}
