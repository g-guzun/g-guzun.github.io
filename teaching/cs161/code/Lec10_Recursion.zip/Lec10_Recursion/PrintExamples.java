
public class PrintExamples
{
    /**
     * Recursively prints all integers n ... 0 (inclusive)
     * @param n non-negative integer
     */
    public static void descendingPrint(int n) {
        if (n > 0) {
            System.out.println(n);
            descendingPrint(n-1);

            // The code below causes a stack overflow error (infinite recursion)
            //descendingPrint(n+1);
        }
    }
}