import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * A pretty useless chatbot
 *
 * @author David
 * @version 10/24/2017
 */
public class ChatBot
{
    private Random rng;
    private ArrayList<String> responses;
    
    /**
     * Creates a new chat bot
     */
    public ChatBot()
    {
        this.rng = new Random();
        this.responses = new ArrayList<>();
        this.fillSnarkyResponses();
    }

    /**
     * Starts up the ChatBot program 
     */
    public void start()
    {
        this.printWelcome();

        Scanner keyboard = new Scanner(System.in);  // Used to get keyboard input
        String userInput;
        do {
            userInput = keyboard.nextLine();       // Get user input
            
            if (!userInput.equalsIgnoreCase("bye")) {
                this.printSnarkyResponse(); 
            }
        } while (!userInput.equalsIgnoreCase("bye"));
        this.printGoodbye();
    }
    
    /**
     * Fill a set of snarky responses
     */
    private void fillSnarkyResponses()
    {
        this.responses.add("Say, do you like cats?");
        this.responses.add("No one has ever complained about this before.");
        this.responses.add("You're not making any sense. Could you ask in a different way?");
        this.responses.add("I just Googled it. It doesn't know either.");
        this.responses.add("Calm down, I don't want to argue.");
    }
    
    /**
     * Prints a welcome message
     */
    private void printWelcome()
    {
        System.out.println("Tech support! How can I help?");
        System.out.println("Type 'bye' to end this session.");
    }

    /**
     * Prints good bye message
     */
    private void printGoodbye()
    {
        System.out.println("Glad I was able to help. Bye!");
    }
    
    /**
     * @return a random response
     */
    private void printSnarkyResponse()
    {
        // Get a random response from the list
        String resp = responses.get(this.rng.nextInt(this.responses.size()));
        System.out.println(resp);
    }
}