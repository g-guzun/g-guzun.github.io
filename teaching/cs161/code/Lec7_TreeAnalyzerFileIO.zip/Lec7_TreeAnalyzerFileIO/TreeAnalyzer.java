import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class analyzes trees.
 * 
 * @author David
 * @version 10/27/2016
 */
public class TreeAnalyzer
{
    private ArrayList<Double> listOfHeights;
    private String filename;
       
    /**
     * Creates a TreeAnalyzer which opens uses the data from the given file
     * @param filename the input filename
     */
    public TreeAnalyzer(String inputFileName) throws FileNotFoundException {
        this.filename = inputFileName;
        this.listOfHeights = new ArrayList<>();
        this.open();
    }
    
    
    /**
     * Opens the file stored in the field
     */
    public void open() throws FileNotFoundException {
        // attempt to open file
        Scanner file = new Scanner(new File(this.filename));
        
        // opened file successfully!
        while (file.hasNext()) {
            // there's at least a line yet to be read
            String line = file.nextLine();  // format: "type,height"
            String[] tokens = line.split(","); // [type, height]
            double currentHeight = Double.parseDouble(tokens[1]);   // height (in double)
            this.listOfHeights.add(currentHeight);
        }
        
        // close the file
        file.close(); 
    }
    
    
    /**
     * @return height of the tallest tree
     */
    public double getTallest() {
        if (this.listOfHeights.size() > 0) {
            double tallest = this.listOfHeights.get(0);
            for (int i = 1; i < this.listOfHeights.size(); i++) {
                if (tallest < this.listOfHeights.get(i)) {
                    tallest = this.listOfHeights.get(i);
                }
            }
            return tallest;
        }
        return 0;
    }
    
    /**
     * Counts the number of trees read in from file shorter than given limit
     * @param limit a given height with which to compare
     * @return number of trees
     */
    public ArrayList<Double> getTreesShorterThan(double limit) {
        ArrayList<Double> shortTrees = new ArrayList<>();
        for (int i = 0; i < this.listOfHeights.size(); i++) {
            if (this.listOfHeights.get(i) < limit) {
                shortTrees.add(this.listOfHeights.get(i));
            }
        }
        return shortTrees;
    }
    
    /**
     * Counts trees of a given species
     * @param species
     * @return the number of trees of the given species
     */
    public int countTreesBySpecies(String species) throws FileNotFoundException {
        // use a hashmap to store "species --> count" entries!
        HashMap<String, Integer> speciesTbl = new HashMap<>();

        // attempt to open file
        Scanner file = new Scanner(new File(this.filename));

        // fill the map!
        while (file.hasNext()) {
            String line = file.nextLine();      // read a line of input from file
            String[] tokens = line.split(",");  // split by comma gives: [species, height]
            
            if (!speciesTbl.containsKey(tokens[0])) {
                // This is the first tree we've seen for this species
                speciesTbl.put(tokens[0], 1);
            }
            else {
                // We've seen this species before. Add one to its count
                int num = speciesTbl.get(tokens[0]);
                speciesTbl.put(tokens[0], num+1);
            }
        }
        System.out.println(speciesTbl);
        // Map is full. Now we just have to lookup the value by species
        return speciesTbl.get(species);
    }
    

    /**
     * Prints a summary of the data
     */    
    public void report() {
        System.out.println("----------------------");
        System.out.println("File name: " + this.filename);
        System.out.println("----------------------");
        System.out.println("Number of Trees: " + this.listOfHeights.size());
        System.out.println("Tallest tree: " + this.getTallest());
    }

    /**
     * Writes a summary of the data to the file indicated by the given filename
     * @param filename the name of file to write into
     */    
    public void reportToFile(String filename) throws FileNotFoundException {
        PrintWriter fileOut = new PrintWriter(new File(filename));
        fileOut.println("--------------------");
        fileOut.println("File name: " + this.filename);
        fileOut.println("----------------------");
        fileOut.println("Number of Trees: " + this.listOfHeights.size());
        fileOut.println("Tallest tree: " + this.getTallest());
        fileOut.close();    //save and close the file
    }
}
