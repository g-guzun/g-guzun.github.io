/**
 * Instructor-provided code.  You should not modify this file!
 * An Accidental represents a musical accidental; sharp, flat or natural.
 */ 
public enum Accidental {	
	SHARP, NATURAL, FLAT
}