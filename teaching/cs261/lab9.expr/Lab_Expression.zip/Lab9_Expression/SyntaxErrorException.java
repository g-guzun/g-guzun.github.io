
public class SyntaxErrorException extends IllegalArgumentException {
    public SyntaxErrorException() {
        super();
    }

    public SyntaxErrorException(String message) {
        super(message);
    }
}
