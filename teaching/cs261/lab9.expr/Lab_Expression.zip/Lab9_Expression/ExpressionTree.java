import java.util.Stack;

public class ExpressionTree
{
    private EvaluableNode root; //root of the expression tree

    /**
     * <<READ IT, BUT DO NOT MAKE CHANGES TO THIS CONSTRUCTOR>>
     * 
     * The constructor takes an infix expression as a String, builds and stores a tree to 
     * represent it.
     * @param infix A parenthesized infix expression, such as, "( 4 + ( 5 * 6 ) )"
     */
    public ExpressionTree(String infix) throws SyntaxErrorException {
        String postfix = Infix2Postfix.convert(infix);
        this.root = this.buildTree(postfix);
    }
    
    /**
     * Takes an expression in postfix form (as a string), and
     * builds an expression tree.
     * @param expr A postfix expression
     * @return root of the expression tree you built
     */
    private EvaluableNode buildTree(String expr) {
        // TODO
        return null;
    }

    /**
     * Evaluate the expression and return its value as a double. 
     * All we need to do is ask the root node in the tree to evaluate itself.
     * @return
     */
    public double evaluate() {
        //TODO
        return Double.NaN;
    }

    /**
     * @returns a String containing a fully-parenthesized representation of the expression. 
     * This expression should have spaces separating the operators, operands, and parentheses 
     * so that the resulting string could be used as input to the Expression constructor. 
     * All we need to do is ask the root node to print itself.
     */
    @Override
    public String toString() {
        //TODO 
        return "";
    }
}
