public class ValueNode implements EvaluableNode
{
    //TODO
}
