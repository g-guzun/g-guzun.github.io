public class Test {
    public static void main(String[] args) throws Exception {
        ExpressionTree e = new ExpressionTree("( 45 / 4.5 )");
        System.out.println(e.toString());
        System.out.println(e.evaluate());

        // e = new Expression("( ( 1 + ( 2 * 3 ) ) - 4 )");
        // System.out.println(e.toString());
        // System.out.println(e.evaluate(null));

        e = new ExpressionTree("( ( 1 + ( 2.9 * -3                ) ) - 4 )");
        System.out.println(e.toString());
        System.out.println(e.evaluate());
/*
        e = new Expression("( 1 + ( 2 * ( 3 - 4 ) ) )");
        System.out.println(e.toString());
        System.out.println(e.evaluate(null));

        e = new Expression("( 1 + ( 5 / 3 ) )");
        System.out.println(e.toString());
        System.out.println(e.evaluate(null));
*/
    }
}
