public interface EvaluableNode {
   double evaluate();
   String toString();
}