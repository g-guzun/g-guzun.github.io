public class BinaryOpNode implements EvaluableNode {
    //TODO
}
