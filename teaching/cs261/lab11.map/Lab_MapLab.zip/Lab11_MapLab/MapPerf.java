
/**
 * 
 * @author David
 * @version 4/16/18
 */
public interface MapPerf {
    /**
     * Resets the probe count
     */
    void resetProbes();
    
    /**
     * @return the number of probes
     */
    long getProbes();
    
    /**
     * @return the load factor of the map
     */
    double getLoadFactor();
}
