
/**
 *  This class creates a HistoryDie instance and exercises it a bit.
 *  
 *  @author Brad Richards
 */
public class Tester
{
    public static final int NUM_ROLLS = 1000;
    public static final int LIMIT = 100;
    
    public static void main(String[] args) {
        HistoryDie d = new HistoryDie(6);
        int result = 0;
        
        result = DieRoller.rollRepeatedly(d, NUM_ROLLS);
        System.out.println("In "+NUM_ROLLS+" rolls, total was "+result);
        result = DieRoller.rollUntil(d, LIMIT);
        System.out.println("Took "+result+" rolls to break "+LIMIT);
    }
}
