import java.util.List;

/**
 * Here are some methods for you to write
 * 
 * @author David 
 * @version 3/24/18
 */
public class Recursion
{
    /**
     * Determine the number of digits in a given integer.
     * 
     * @param n a positive integer
     * @return the number of digits in n
     */
    public static int countDigits(int n) {
        return 0;
    }

    /**
     * Determine the greatest common divisor (gcd) between m and n
     * 
     * @param m a positive integer
     * @param n a positive integer
     * @return the gcd between m and n
     */
    public static int gcd(int m, int n) {
        return 0;
    }

    
    /**
     * Q3: Determines if the given list contains consecutive numbers.
     */
    public static boolean isConsecutive(List<Integer> list) {
        return false;
    }
    
    /**
     * Q4: Reverses the given list.
     * @param list
     * @param start Current start position of the list
     * @param end   Current end position of the list
     */
    public static void reverse(List<Integer> list) {
    }
    private static void reverseHelper(List<Integer> list, int start, int end) {
    }

    /**
     * Q5: Prime number checker
     * @param n The number to check
     * @param divisor The current number by which to divide n
     */
    public static boolean isPrimeHelper(int n) {
        return false;
    }
    private static boolean isPrimeHelper(int n, int divisor) {
        return false;
    }    
}
