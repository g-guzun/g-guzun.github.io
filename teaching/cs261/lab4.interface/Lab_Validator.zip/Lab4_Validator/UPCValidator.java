public class UPCValidator {
    protected int LENGTH = 12; // UPC's are 12 digits long
    protected int[] payload;
    protected int checkSum;

    /**
     * Loads a number sequence for validation
     * 
     * @param num the sequence to be verified for correctness
     * @return false if the length of the sequence is unexpected, true otherwise
     */
    public boolean loadSequence(String sequence) {
        // TODO
        return false;
    }

    /**
     * Checks the sequence payload against the check digit
     * 
     * @return true if validated, false otherwise
     */
    public boolean validate() {
        // TODO
        return false;
    }
}
