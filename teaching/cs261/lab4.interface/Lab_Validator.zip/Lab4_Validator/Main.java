/**
 * The main method spins up the GUI
 */
public class Main {
  public static void main(String[] args) {
    // instantiate a GUI to use the UPCValidator
    new GUI(new UPCValidator());
  }
}
